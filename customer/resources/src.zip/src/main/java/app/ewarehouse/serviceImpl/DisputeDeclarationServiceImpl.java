package app.ewarehouse.serviceImpl;


import app.ewarehouse.dto.DisputeDeclarationRequest;
import app.ewarehouse.dto.DisputeDeclarationResponse;
import app.ewarehouse.entity.*;
import app.ewarehouse.exception.CustomEntityNotFoundException;
import app.ewarehouse.exception.CustomGeneralException;
import app.ewarehouse.repository.DisputeDeclarationRepository;
import app.ewarehouse.service.DisputeDeclarationService;
import app.ewarehouse.util.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Slf4j
public class DisputeDeclarationServiceImpl implements DisputeDeclarationService {
    private final DisputeDeclarationRepository disputeDeclarationRepository;
    private final UserIdConstants userIdConstants;
    final Validator validator;
    private final ErrorMessages errorMessages;


    @Autowired
    public DisputeDeclarationServiceImpl(DisputeDeclarationRepository disputeDeclarationRepository, UserIdConstants userIdConstants, Validator validator, ErrorMessages errorMessages) {
        this.disputeDeclarationRepository = disputeDeclarationRepository;
        this.userIdConstants = userIdConstants;
        this.validator = validator;
        this.errorMessages = errorMessages;
    }


    @Override
    @Transactional
    public String create(String data) {
        log.info("Inside create method of DisputeDeclarationServiceImpl");

        try {
            DisputeDeclarationRequest disputeDeclarationRequest = new ObjectMapper()
                    .readValue(CommonUtil.inputStreamDecoder(data), DisputeDeclarationRequest.class);

            Set<ConstraintViolation<DisputeDeclarationRequest>> violations = validator.validate(disputeDeclarationRequest);
            if (!violations.isEmpty()) {
                throw new CustomGeneralException(violations);
            }

            byte[] decode = Base64.getDecoder().decode(disputeDeclarationRequest.getBase64EncodedSupportingDocument().getBytes());
            String uniqueFileName = "Dispute_Declaration_" + UUID.randomUUID();

            String file_url = DocumentUploadutil.uploadFileByte(uniqueFileName, decode, FolderAndDirectoryConstant.DISPUTE_DECLARATION_SUPPORTING_DOCS_FOLDER);

            if (file_url.startsWith("Document")) {
                throw new IllegalArgumentException(file_url);
            }

            String filePath = file_url.substring(file_url.indexOf(FolderAndDirectoryConstant.DISPUTE_DECLARATION_SUPPORTING_DOCS_FOLDER));

            DisputeDeclaration disputeDeclaration = DisputeDeclaration.builder()
                    .inspectorSuspensionComplaint(InspectorSuspensionComplaint.builder().complaintId(disputeDeclarationRequest.getApplicantId()).build())
                    .dateOfOccurrence(disputeDeclarationRequest.getDateOfOccurrence())
                    .locationOfOccurrence(disputeDeclarationRequest.getLocationOfOccurrence())
                    .disputeCategory(DisputeCategory.builder().disputeCategoryId(disputeDeclarationRequest.getDisputeCategoryId()).build())
                    .descriptionOfDispute(disputeDeclarationRequest.getDescriptionOfDispute())
                    .disputeSupportingDocumentType(DisputeSupportingDocumentType.builder().supportingDocTypeId(disputeDeclarationRequest.getDisputeSupportingDocumentType()).build())
                    .supportingDocument(filePath)
                    .status(Status.Pending)
                    .actionTakenBy(userIdConstants.getDisputeOfficer())
                    .build();

            DisputeDeclaration declaration = disputeDeclarationRepository.save(disputeDeclaration);
            return declaration.getDisputeId();

        } catch (Exception e) {
            log.error("Error occurred in create method of DisputeDeclarationServiceImpl: {} ", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    @Override
    @Transactional(readOnly = true)
    public List<DisputeDeclarationResponse> getAll() {
        log.info("Inside getAll method of DisputeDeclarationServiceImpl");
        return disputeDeclarationRepository.findAll().stream()
                .map(Mapper::mapToDisputeDeclarationResponse)
                .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Map<String, Object> getAll(Integer pageNumber, Integer pageSize) {
        log.info("Inside getAll paginated method of DisputeDeclarationServiceImpl");
        Map<String, Object> map = new HashMap<>();
        try {
            Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("createdAt").descending());
            Page<DisputeDeclaration> disputeDeclarationPage = disputeDeclarationRepository.findAllDisputeDeclarations(pageable);
            List<DisputeDeclarationResponse> disputeDeclarations = disputeDeclarationPage.getContent()
                    .stream()
                    .map(Mapper::mapToDisputeDeclarationResponse)
                    .toList();

            map.put("status", "200");
            map.put("payload", disputeDeclarations);
            map.put("totalDisputes", disputeDeclarationPage.getTotalElements());
            map.put("totalPages", disputeDeclarationPage.getTotalPages());
            return map;

        } catch (Exception e) {
            log.error("Error occurred in paginated getAll method of DisputeDeclarationServiceImpl: {}", e.getMessage());
            throw new RuntimeException(e);
        }
    }


    @Override
    public List<DisputeDeclaration> getPendingDisputesForUser(Integer userId) {
        return disputeDeclarationRepository.findDisputesByUser(Status.Pending, userId);
    }

    @Override
    public Map<String, Object> getPendingDisputesForUser(Integer pageNumber, Integer pageSize, Integer userId) {
        log.info("Inside getAllPending paginated method of DisputeDeclarationServiceImpl");
        Map<String, Object> map = new HashMap<>();
        try {
            Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("createdAt").descending());

            Page<DisputeDeclaration> disputeDeclarationPage = disputeDeclarationRepository.findPendingDisputesForUser(Status.Pending, userId, pageable);
            List<DisputeDeclarationResponse> disputeDeclarationResponses = disputeDeclarationPage.getContent()
                    .stream()
                    .map(Mapper::mapToDisputeDeclarationResponse)
                    .toList();

            map.put("status", "200");
            map.put("payload", disputeDeclarationResponses);
            map.put("totalPendingDisputes", disputeDeclarationPage.getTotalElements());
            map.put("totalPages", disputeDeclarationPage.getTotalPages());

            return map;

        } catch (Exception e) {
            log.info("Error occurred in getAllPending paginated method of DisputeDeclarationServiceImpl: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    public Map<String, Object> getForwardedDisputes(Integer pageNumber, Integer pageSize, Integer userId) {
        log.info("Inside getAllForwarded paginated method of DisputeDeclarationServiceImpl");
        Map<String, Object> map = new HashMap<>();

        //TODO: Should be refactored to avoid this hack
        if (userId.equals(userIdConstants.getInspector())) {
            map.put("payload", null);
            return map;
        }

        try {
            Pageable pageable = PageRequest.of(pageNumber, pageSize, Sort.by("createdAt").descending());
            Page<DisputeDeclaration> disputeDeclarationPage;

            if (userId.equals(userIdConstants.getCeo())) {
                disputeDeclarationPage = disputeDeclarationRepository.findForwardedDisputesForCeo(Status.Pending, userIdConstants.getCeo(), pageable);
            } else if (userId.equals(userIdConstants.getOicLegal())) {
                disputeDeclarationPage = disputeDeclarationRepository.findForwardedDisputesForOic(Status.Pending, userIdConstants.getOicLegal(), pageable);
            } else {
                throw new CustomGeneralException(errorMessages.getNotAuthorized());
            }

            List<DisputeDeclarationResponse> disputeDeclarationResponses = disputeDeclarationPage.getContent()
                    .stream()
                    .map(Mapper::mapToDisputeDeclarationResponse)
                    .toList();

            map.put("status", "200");
            map.put("payload", disputeDeclarationResponses);
            map.put("totalForwardedDisputes", disputeDeclarationPage.getTotalElements());
            map.put("totalPages", disputeDeclarationPage.getTotalPages());
            return map;
        } catch (Exception e) {
            log.info("Error occurred in getForwardedDisputes method of DisputeDeclarationServiceImpl: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public DisputeDeclarationResponse getByDisputeDeclarationNumber(String disputeDeclarationNumber) {
        try {
            DisputeDeclaration disputeDeclaration = disputeDeclarationRepository.findById(disputeDeclarationNumber)
                    .orElseThrow(() -> new CustomEntityNotFoundException(errorMessages.getEntityNotFound()));

            return Mapper.mapToDisputeDeclarationResponse(disputeDeclaration);

        } catch (Exception e) {
            log.info("Error occurred in getByDisputeDeclarationNumber method of DisputeDeclarationServiceImpl: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public void rejectDispute(String disputeDeclarationNumber, Integer userId, String remark) {
        DisputeDeclaration dispute = disputeDeclarationRepository.findById(disputeDeclarationNumber)
                .orElseThrow(() -> new CustomEntityNotFoundException(errorMessages.getEntityNotFound()));
        try {
            if (!userId.equals(userIdConstants.getCeo())) {
                disputeDeclarationRepository.save(dispute);
            }
            dispute.setStatus(Status.Rejected);
            dispute.setCeoRemark(remark);
            dispute.setRemark(remark);
        } catch (Exception e) {
            log.info("Error occurred in rejectDispute method of DisputeDeclarationServiceImpl: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

    @Override
    public void approveDispute(String disputeDeclarationNumber, Integer userId, String remark) {
        DisputeDeclaration dispute = disputeDeclarationRepository.findById(disputeDeclarationNumber)
                .orElseThrow(() -> new CustomEntityNotFoundException(errorMessages.getEntityNotFound()));
        try {
            if (!userId.equals(userIdConstants.getTechnical())) {
                throw new IllegalArgumentException(errorMessages.getNotAuthorized());
            }

            dispute.setInspectorRemark(remark);
            dispute.setRemark(remark);
            dispute.setStatus(Status.Approved);
            disputeDeclarationRepository.save(dispute);
        } catch (Exception e) {
            log.info("Error occurred in approve method of DisputeDeclarationServiceImpl: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }


    public void forwardDispute(String declarationNumber, Integer userId, String remark) {
        DisputeDeclaration dispute = disputeDeclarationRepository.findById(declarationNumber)
                .orElseThrow(() -> new CustomEntityNotFoundException(errorMessages.getEntityNotFound()));

        try {
            if (userId.equals(userIdConstants.getCeo())) {
                dispute.setActionTakenBy(userIdConstants.getOicLegal());
                dispute.setCeoRemark(remark);
            } else if (userId.equals(userIdConstants.getOicLegal())) {
                dispute.setActionTakenBy(userIdConstants.getInspector());
                dispute.setOicLegalRemark(remark);
            } else {
                throw new CustomGeneralException(errorMessages.getNotAuthorized());
            }
            disputeDeclarationRepository.save(dispute);
        } catch (Exception e) {
            log.info("Error occurred in forwardDispute method of DisputeDeclarationServiceImpl: {}", e.getMessage(), e);
            throw new RuntimeException(e);
        }
    }

}


