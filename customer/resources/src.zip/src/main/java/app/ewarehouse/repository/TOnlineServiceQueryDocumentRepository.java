package app.ewarehouse.repository;

import app.ewarehouse.entity.TOnlineServiceQueryDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface TOnlineServiceQueryDocumentRepository extends JpaRepository<TOnlineServiceQueryDocument, Integer> {

}
