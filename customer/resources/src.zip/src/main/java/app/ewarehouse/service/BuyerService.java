package app.ewarehouse.service;

import app.ewarehouse.dto.BuyerResponse;
import app.ewarehouse.entity.RegistrationType;
import app.ewarehouse.entity.Status;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Date;
import java.util.List;

public interface BuyerService {
    String save(String buyer);
    BuyerResponse getById(String Id);
    BuyerResponse findByIdAndRegType(String id);
    List<BuyerResponse> getAll();
    Page<BuyerResponse> getAll(Pageable pageable);
    String deleteById(String id);

    public String takeAction(String data);

    Page<BuyerResponse> getFilteredBuyers(Date fromDate, Date toDate, Status status, Pageable pageable);

    Page<BuyerResponse> getFilteredBuyers(Date fromDate, Date toDate, Status status, String search, String sortColumn,
                                          String sortDirection, Pageable pageable);
}
