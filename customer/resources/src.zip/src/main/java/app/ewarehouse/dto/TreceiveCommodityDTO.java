package app.ewarehouse.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TreceiveCommodityDTO {
    private String txtDepositorsIntId;
    private String intCommodityType;
    private Double intQuantity;
    private String intSeasonalityId;
    private String txtGrade;
    private String txtLotNo;
}
