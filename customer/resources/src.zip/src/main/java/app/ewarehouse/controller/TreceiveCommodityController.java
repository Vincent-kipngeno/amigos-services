package app.ewarehouse.controller;

import app.ewarehouse.entity.TreceiveCommodity;
import app.ewarehouse.entity.TrevocationOfCertificateOfCompliance;
import app.ewarehouse.service.TreceiveCommodityService;
import app.ewarehouse.util.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("admin/receiveCommodity")
@CrossOrigin("*")
public class TreceiveCommodityController {

    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    TreceiveCommodityService service;

    @GetMapping
    ResponseEntity<?> getAll() throws JsonProcessingException {
       List<TreceiveCommodity> response = service.findAll();
        return ResponseEntity.ok(CommonUtil.encodedJsonResponse(response,objectMapper));
    }

    @PostMapping
    ResponseEntity<?> receiveCommodity(@RequestBody String data) throws JsonProcessingException {
       String response = service.save(data);
        return  ResponseEntity.ok(CommonUtil.encodedJsonResponse(response,objectMapper));
    }

    @GetMapping("/paginated")
    ResponseEntity<?> getAllPaginated(
            @RequestParam(value = "page") int page,
            @RequestParam(value = "size") int size) throws JsonProcessingException {
        Page<TreceiveCommodity> suspensionsPage = service.getAllCommodities(page,size);

        Map<String, Object> response = new HashMap<>();
        response.put("content", suspensionsPage.getContent());
        response.put("totalPages", suspensionsPage.getTotalPages());
        response.put("totalElements", suspensionsPage.getTotalElements());

        return ResponseEntity.ok(CommonUtil.encodedJsonResponse(response,objectMapper));
    }

    @GetMapping("{id}")
    ResponseEntity<?> getCommodityByReceiveId(@PathVariable String id ) throws Exception {
        TreceiveCommodity commodity = service.getCommodityByReceiveId(id);
        return ResponseEntity.ok(CommonUtil.encodedJsonResponse(commodity,objectMapper));
    }

}
