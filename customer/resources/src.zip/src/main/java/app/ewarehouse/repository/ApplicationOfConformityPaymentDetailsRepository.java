package app.ewarehouse.repository;

import app.ewarehouse.entity.ApplicationOfConformityPaymentDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApplicationOfConformityPaymentDetailsRepository extends JpaRepository<ApplicationOfConformityPaymentDetails, Integer> {

}
