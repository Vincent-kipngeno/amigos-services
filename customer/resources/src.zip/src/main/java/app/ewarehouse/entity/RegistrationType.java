package app.ewarehouse.entity;

public enum RegistrationType {
    Depositor,
    Buyer,
    DepositorBuyer

}
