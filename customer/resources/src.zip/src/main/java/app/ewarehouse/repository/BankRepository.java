package app.ewarehouse.repository;

import app.ewarehouse.entity.Bank;
import app.ewarehouse.entity.LegalStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BankRepository extends JpaRepository<Bank, Integer> {
    Bank findByIntIdAndBitDeletedFlag(Integer intId, boolean bitDeletedFlag);

    List<Bank> findAllByBitDeletedFlag(Boolean bitDeletedFlag);
}
