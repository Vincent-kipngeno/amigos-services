package app.ewarehouse.repository;

import app.ewarehouse.entity.County;
import app.ewarehouse.entity.SubCounty;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
@Repository
public interface SubCountyRepository extends JpaRepository<SubCounty, Integer> {

    @Modifying
    @Transactional
    @Query(value = "UPDATE t_sub_county SET bitDeletedFlag = 1 WHERE intId = :id", nativeQuery = true)
    void deleteSubCounty(@Param("id") Integer id);
	
	List<SubCounty> findByCountyAndBitDeletedFlag(County county, boolean bitDeletedFlag);

    Optional<SubCounty> findByIntIdAndBitDeletedFlag(Integer intId, boolean bitDeletedFlag);

    List<SubCounty> findAllByBitDeletedFlag(Boolean bitDeletedFlag);
}
