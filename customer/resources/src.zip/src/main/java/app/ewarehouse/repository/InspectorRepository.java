package app.ewarehouse.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import app.ewarehouse.entity.Action;
import app.ewarehouse.entity.Inspector;
import app.ewarehouse.entity.Stakeholder;
import app.ewarehouse.entity.Status;

public interface InspectorRepository extends JpaRepository<Inspector, Integer> {
	Page<Inspector> findByStatusAndForwardedTo(Status status, Stakeholder forwardedTo, Pageable pageable);

	Page<Inspector> findByStatusInAndForwardedToAndCurrentActionIn(List<Status> statuses, Stakeholder ceo,
			List<Action> actions, Pageable pageable);

	Page<Inspector> findByStatusInAndForwardedTo(List<Status> statuses, Stakeholder forwardedTo, Pageable pageable);

	Page<Inspector> findByCurrentActionAndForwardedTo(Action status, Stakeholder forwardedTo, Pageable pageable);
	
	Page<Inspector> findByStatusInAndForwardedToIn(List<Status> statuses, List<Stakeholder> stakeholders, Pageable pageable);

}
