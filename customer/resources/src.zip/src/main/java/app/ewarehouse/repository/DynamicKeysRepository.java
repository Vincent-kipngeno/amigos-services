package app.ewarehouse.repository;

import app.ewarehouse.entity.DynamicKeys;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DynamicKeysRepository extends JpaRepository<DynamicKeys, Integer> {

	List<DynamicKeys> findByBitDeletedFlag(boolean b);

	
}
