package app.ewarehouse.serviceImpl;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import app.ewarehouse.dto.OperatorLicenceDTO;
import app.ewarehouse.dto.ResponseDTO;
import app.ewarehouse.dto.StakeHolderActionRequestData;
import app.ewarehouse.entity.Action;
import app.ewarehouse.entity.OperatorLicence;
import app.ewarehouse.entity.OperatorLicenceFiles;
import app.ewarehouse.entity.OperatorLicenceRemarks;
import app.ewarehouse.entity.Stakeholder;
import app.ewarehouse.entity.Status;
import app.ewarehouse.exception.CustomGeneralException;
import app.ewarehouse.repository.OperatorLicenceRepository;
import app.ewarehouse.service.OperatorLicenceService;
import app.ewarehouse.util.CommonUtil;
import app.ewarehouse.util.JsonFileExtractorUtil;

@Service
public class OperatorLicenceServiceImpl implements OperatorLicenceService {

    private  OperatorLicenceRepository operatorLicenceRepository;
    
    private OperatorLicenceRemarkRepository operatorLicenceRemarkRepository;
    
    private OperatorLicence operatorLicence1;
    
    @Autowired
    private ObjectMapper objectMapper;
	
	ResponseDTO<String> responseDTO = new ResponseDTO<>();

    public OperatorLicenceServiceImpl(OperatorLicenceRepository operatorLicenceRepository,OperatorLicenceRemarkRepository operatorLicenceRemarkRepository) {
        this.operatorLicenceRepository = operatorLicenceRepository;
        this.operatorLicenceRemarkRepository = operatorLicenceRemarkRepository;
    }
    
    @Override
	public String handleAction(String actionRequestData, Stakeholder forwardedTo, Stakeholder actionTakenBy,
			Action action, Status status) throws JsonProcessingException {
		String decodedData = CommonUtil.inputStreamDecoder(actionRequestData);
		StakeHolderActionRequestData actionRequest;
		try {
			actionRequest = objectMapper.readValue(decodedData, StakeHolderActionRequestData.class);
			System.out.println("StakeHolder Action Request data...."+actionRequest);
		} catch (Exception e) {
			throw new CustomGeneralException("Invalid data format: " + e);
		}
		System.out.println(actionRequest.getId());
		

		OperatorLicence operatorLicence = operatorLicenceRepository.findById(actionRequest.getId())
				.orElseThrow(() -> new RuntimeException("Operator Licence not found"));
		
		System.out.println("Fetched Operator Licence by id data ..."+operatorLicence);

		OperatorLicenceRemarks remark = new OperatorLicenceRemarks();
		remark.setOperatorLicence(operatorLicence);
		remark.setRemark(actionRequest.getRemark());
		remark.setCreatedBy(actionRequest.getCreatedBy());
		remark.setStakeholder(actionTakenBy);
//		System.out.println("Remark"+remark);
		operatorLicenceRemarkRepository.save(remark);
		
		if (actionRequest.getInspectionReport() != null && !actionRequest.getInspectionReport().getFilePath().isBlank()) {
	        OperatorLicenceFiles file = actionRequest.getInspectionReport();
	        file.setFilePath(JsonFileExtractorUtil.uploadFile(file.getFilePath()));
	        file.setOperatorLicence(operatorLicence);

	        if (operatorLicence.getFiles() == null) {
	            operatorLicence.setFiles(new ArrayList<>());
	        }
	        operatorLicence.getFiles().add(file);
	        System.out.println("Files...." + operatorLicence.getFiles());
	    }

		if ("forward".equalsIgnoreCase(actionRequest.getAction())) {
			operatorLicence.setForwardedTo(forwardedTo);
			operatorLicence.setAction(action);
			operatorLicence.setStatus(status);
			System.out.println("Current action..."+action);
			System.out.println("Current Status..."+status);
		} else if ("reject".equalsIgnoreCase(actionRequest.getAction())) {
			operatorLicence.setStatus(Status.Rejected);
			operatorLicence.setForwardedTo(Stakeholder.APPLICANT);
			operatorLicence.setAction(Action.Rejected);
		}
		System.out.println("Final Operator Licence data I am saving...."+operatorLicence);

		operatorLicenceRepository.save(operatorLicence);

		ResponseDTO<String> responseDTO = new ResponseDTO<>();
		responseDTO.setStatus(HttpStatus.OK.value());
		responseDTO.setResult("Action successfully completed");
		responseDTO.setMessage("Operator Licence action processed successfully");

		return CommonUtil.inputStreamEncoder(objectMapper.writeValueAsString(responseDTO)).toString();
	}
    
    @Override
    public Page<OperatorLicenceDTO> getApplications(Pageable pageable, Status status, Stakeholder stakeholder, Action action) {
        Page<OperatorLicence> licences = operatorLicenceRepository.findByStatusAndForwardedToAndAction(status, stakeholder, action, pageable);
//        System.out.println(licences.getContent());
        return licences.map(this::convertToDto);
    }

    private OperatorLicenceDTO convertToDto(OperatorLicence operatorLicence) {
        OperatorLicenceDTO dto = new OperatorLicenceDTO();
        dto.setId(operatorLicence.getId());
        dto.setBusinessName(operatorLicence.getBusinessName());
        dto.setBusinessRegNumber(operatorLicence.getBusinessRegNumber());
        dto.setBusinessEntityType(operatorLicence.getBusinessEntityType());
        dto.setBusinessAddress(operatorLicence.getBusinessAddress());
        dto.setEmailAddress(operatorLicence.getEmailAddress());
        dto.setPhoneNumber(operatorLicence.getPhoneNumber());
        dto.setKraPin(operatorLicence.getKraPin());
        dto.setPhysicalAddressWarehouse(operatorLicence.getPhysicalAddressWarehouse());
        dto.setWarehouseSize(operatorLicence.getWarehouseSize());
        dto.setGoodsStored(operatorLicence.getGoodsStored());
        dto.setStorageCapacity(operatorLicence.getStorageCapacity());
        dto.setSecurityMeasures(operatorLicence.getSecurityMeasures());
        dto.setWasteDisposalMethods(operatorLicence.getWasteDisposalMethods());
        dto.setDeclaration(operatorLicence.getDeclaration());
        dto.setPaymentMethod(operatorLicence.getPaymentMethod());
        dto.setStatus(operatorLicence.getStatus());
        dto.setAction(operatorLicence.getAction());
        dto.setForwardedTo(operatorLicence.getForwardedTo());
        dto.setFiles(operatorLicence.getFiles());
        dto.setRemarks(operatorLicence.getRemarks());
        return dto;
    }
       
	@Override
	public String saveOperatorLicence(String operatorLicence) throws JsonProcessingException {	
		String decodedData = CommonUtil.inputStreamDecoder(operatorLicence);
		System.out.println(decodedData);
		try {
			operatorLicence1 = new ObjectMapper().readValue(decodedData, OperatorLicence.class);
		} catch (Exception e) {
			throw new CustomGeneralException("Invalid data format: " + e);
		}
		System.out.println(operatorLicence1);
    	operatorLicence1.setFiles(operatorLicence1.getFiles().stream().map(this::saveFile).toList());
    	System.out.println(operatorLicence1);
    	operatorLicence1.setStatus(Status.Pending); 
    	operatorLicence1.setForwardedTo(Stakeholder.TECHNICAL); 
    	operatorLicence1.setAction(Action.Pending);
    	OperatorLicence savedOperatorLicence =operatorLicenceRepository.save(operatorLicence1);
    	Integer operatorId = savedOperatorLicence.getId();
    	
		 responseDTO.setStatus(HttpStatus.CREATED.value());
         responseDTO.setResult("Successfully Added!");
         responseDTO.setMessage("Your Operator Licence Number is " + operatorId);
         return CommonUtil.inputStreamEncoder(objectMapper.writeValueAsString(responseDTO)).toString();
	}

    private OperatorLicenceFiles saveFile(OperatorLicenceFiles operatorLicenceFiles) {
    	operatorLicenceFiles.setFilePath(JsonFileExtractorUtil.uploadFile(operatorLicenceFiles.getFilePath()));
    	operatorLicenceFiles.setOperatorLicence(this.operatorLicence1);
        return operatorLicenceFiles;
    }
    
    public Page<OperatorLicence> getOperatorLicences(PageRequest pageRequest) {
        return operatorLicenceRepository.findAll(pageRequest);
    }

	
}
