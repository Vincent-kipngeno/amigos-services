package app.ewarehouse.service;

import app.ewarehouse.dto.DisputeSupportingDocumentTypeResponse;

import java.util.List;

public interface DisputeSupportingDocTypeService {
    List<DisputeSupportingDocumentTypeResponse> getAllDisputeSupportingDocumentType();
}
