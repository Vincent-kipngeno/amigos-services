package app.ewarehouse.serviceImpl;
import app.ewarehouse.util.CommonUtil;
import org.json.JSONObject;
import jakarta.persistence.EntityManager;import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.List;
import org.json.JSONArray;
public class DynamicCommonMethodServiceImpl {
private static final Logger logger = LoggerFactory.getLogger(DynamicCommonMethodServiceImpl.class);
//-----------------------------------------------------------------------
//-------------------common method write----------------------------
}