package app.ewarehouse.repository;

import app.ewarehouse.entity.Buyer;
import app.ewarehouse.entity.RegistrationType;
import app.ewarehouse.entity.Status;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface BuyerRepository extends JpaRepository<Buyer, String> {

    Buyer findByIntIdAndBitDeletedFlag(String intId, boolean bitDeletedFlag);

    Optional<Buyer> findByIntIdAndEnmRegistrationTypeInAndEnmStatusAndBitDeletedFlag(String intId,  List<RegistrationType> regTypes,Status status, boolean bitDeletedFlag);

    List<Buyer> findAllByBitDeletedFlagOrderByDtmCreatedOnDesc(Boolean bitDeletedFlag);

    Page<Buyer> findAllByBitDeletedFlagOrderByDtmCreatedOnDesc(Boolean bitDeletedFlag, Pageable pageable);

    @Query("SELECT b FROM Buyer b WHERE b.bitDeletedFlag = false AND (:fromDate IS NULL OR b.dtmCreatedOn >= :fromDate) AND (:toDate IS NULL OR b.dtmCreatedOn <= :toDate) AND (:status IS NULL OR b.enmStatus = :status) order by b.dtmCreatedOn DESC")
    Page<Buyer> findByFilters(@Param("fromDate") Date fromDate, @Param("toDate") Date toDate, @Param("status") Status status, Pageable pageable);

    @Query("SELECT b FROM Buyer b WHERE b.bitDeletedFlag = false " +
            "AND (:fromDate IS NULL OR b.dtmCreatedOn >= :fromDate) " +
            "AND (:toDate IS NULL OR b.dtmCreatedOn <= :toDate) " +
            "AND (:status IS NULL OR b.enmStatus = :status) " +
            "AND (:search IS NULL OR " +
            "LOWER(b.txtName) LIKE LOWER(CONCAT('%', :search, '%')) " +
            "OR LOWER(b.txtEmailAddress) LIKE LOWER(CONCAT('%', :search, '%')) " +
            "OR LOWER(b.txtTelephoneNumber) LIKE LOWER(CONCAT('%', :search, '%')) " +
            "OR CAST(b.intId AS string) LIKE CONCAT('%', :search, '%') " +
            "OR LOWER(CAST(b.enmStatus AS string)) LIKE LOWER(CONCAT('%', :search, '%')) " +
            "OR LOWER(CAST(b.enmRegistrationType AS string)) LIKE LOWER(CONCAT('%', :search, '%')))")
    Page<Buyer> findByFilters(@Param("fromDate") Date fromDate,
                              @Param("toDate") Date toDate,
                              @Param("status") Status status,
                              @Param("search") String search,
                              Pageable pageable);


    @Modifying
    @Transactional
    @Query("UPDATE Buyer b SET b.enmStatus = :status WHERE b.intId = :id")
    int updateBuyerStatus(@Param("id") String id, @Param("status") Status status);

    @Query("Select b.enmStatus FROM Buyer b WHERE b.intId = :id")
    Status getBuyerStatus(@Param("id") String id);
}
