package app.ewarehouse.dto;

import lombok.Data;

@Data
public class DisputeSupportingDocumentTypeResponse {
    private Integer supportingDocTypeId;
    private String supportingDocTypeName;
}
