package app.ewarehouse.serviceImpl;

import app.ewarehouse.entity.TvalidateCommodity;
import app.ewarehouse.entity.TwarehouseReceipt;
import app.ewarehouse.repository.TwarehouseReceiptRepository;
import app.ewarehouse.service.TwarehouseReceiptService;
import app.ewarehouse.util.ErrorMessages;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TwarehouseReceiptServiceImpl implements TwarehouseReceiptService {
    @Autowired
    TwarehouseReceiptRepository repo;
    @Autowired
    ErrorMessages errorMessages;

    @Override
    public Page<TwarehouseReceipt> getAllReceipts(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return Optional.ofNullable(repo.findAllByBitDeleteFlagOrderByDtmCreatedAtDesc(false, pageable)).orElse(Page.empty(pageable));
    }

    @Override
    public List<TwarehouseReceipt> findAll() {
        return repo.findAll();
    }

    @Override
    public TwarehouseReceipt getDetailsById(String txtWarehouseReceiptId) {
        TwarehouseReceipt commodity = repo.findByTxtWarehouseReceiptIdAndBitDeleteFlag(txtWarehouseReceiptId,false);
        if (commodity == null) {
            throw new EntityNotFoundException(errorMessages.getFailedToFetch() +" "+ txtWarehouseReceiptId );
        }
        return commodity;
    }
}
