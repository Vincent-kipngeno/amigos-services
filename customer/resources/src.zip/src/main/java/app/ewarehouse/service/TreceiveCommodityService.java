package app.ewarehouse.service;

import app.ewarehouse.entity.TreceiveCommodity;
import app.ewarehouse.entity.TrevocationOfCertificateOfCompliance;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.data.domain.Page;

import java.util.List;

public interface TreceiveCommodityService {

    Page<TreceiveCommodity> getAllCommodities(int page, int size);

    String save(String complaintFormDto) throws JsonProcessingException;

    TreceiveCommodity getCommodityByReceiveId(String complaintNumber);

    List<TreceiveCommodity> findAll() ;

    TreceiveCommodity getCommodityByDepositorsId(String id);
}
