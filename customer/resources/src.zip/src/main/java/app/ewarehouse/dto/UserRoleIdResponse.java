package app.ewarehouse.dto;

import lombok.Data;

@Data
public class UserRoleIdResponse {
	private String uid;
	private String uname;
	private String loginid;
}
