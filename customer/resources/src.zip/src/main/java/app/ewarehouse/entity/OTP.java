package app.ewarehouse.entity;





import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "otp", schema = "ewrsdevdb")
@Getter
@Setter
public class OTP {
	
	@Id
	@Column(name = "otpid", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int otpId;
	@Column(name = "otp", nullable = false)
	private int generatedOtp;
	@Column(name = "email", nullable = false)
	private String email;
	@Column(name = "mobile")
	private String mobile;
	@Column(name = "ip_address")
	private String ipAddress;
	@Column(name = "edt")
	private Date edt;
	@Column(name = "ludt")
	private Date ludt;
	@Column(name = "flag")
	private int flag;

}
