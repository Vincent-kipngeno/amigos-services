package app.ewarehouse.util;

public class RoleIdConstants {

	public static final int OIC = 2;
    public static final int INSPECTOR = 3;
    public static final int OIC_FINANCE = 1;
    public static final int APPROVER = 4;
    public static final int CEO = 5;
	
}
