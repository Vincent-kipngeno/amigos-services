package app.ewarehouse.dto;

import lombok.Data;

@Data
public class DisputeCategoryResponse {
    private Integer disputeCategoryId;
    private String disputeCategoryName;
}
