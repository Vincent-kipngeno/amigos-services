package app.ewarehouse.entity;

public enum Role {
USER,ADMIN
}
