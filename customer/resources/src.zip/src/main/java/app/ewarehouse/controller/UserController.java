package app.ewarehouse.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/user")
public class UserController {

	@GetMapping("/testuser")
	public ResponseEntity<Map<String, Object>> sayHello(){
		Map<String, Object> response = new HashMap<>();
		response.put("message", "Hii User");
		return ResponseEntity.ok(response);
	}
}
