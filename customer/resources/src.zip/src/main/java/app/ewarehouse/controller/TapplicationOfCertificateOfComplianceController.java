package app.ewarehouse.controller;

import app.ewarehouse.dto.ApplicationCollateralDTO;
import app.ewarehouse.dto.ResponseDTO;
import app.ewarehouse.entity.Status;
import app.ewarehouse.entity.TapplicationOfCertificateOfCompliance;
import app.ewarehouse.service.TapplicationOfCertificateOfComplianceService;
import app.ewarehouse.util.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
@RequestMapping("certComplaince")
@Slf4j
public class TapplicationOfCertificateOfComplianceController {


    @Autowired
    TapplicationOfCertificateOfComplianceService service;

    @Autowired
    private ObjectMapper objectMapper;

    @GetMapping("getAll")
    public ResponseEntity<?> getAllCompliance() throws JsonProcessingException {
        List<TapplicationOfCertificateOfCompliance> certificateOfComplianceList = service.findAll();
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(certificateOfComplianceList)).toString());
    }
    @PostMapping("createApplication")
    public ResponseEntity<?> createApplication(@RequestBody String certApplication) throws JsonProcessingException {
        ApplicationCollateralDTO certCompliance = service.save(certApplication);
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(certCompliance)).toString());
    }

    @GetMapping()
    public ResponseEntity<?> getApplicationByRoleIdAndStatus(@RequestParam Integer roleId,@RequestParam String status) throws JsonProcessingException {
        ApplicationCollateralDTO application = service.getApplication(roleId,status);
        return  ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(application)).toString());
    }

    @PostMapping("/takeAction")
    public ResponseEntity<String> takeAction(@RequestBody String data) throws JsonProcessingException {
        log.info("Inside takeAction method of SuspensionCollateralController");
        return ResponseEntity.ok(CommonUtil.encodedJsonResponse(service.takeAction(data), objectMapper));
    }

    @GetMapping("/roleView")
    public ResponseEntity<String> getByRoleView(@RequestParam(required = false) Integer officerId,
                                                @RequestParam(required = false) Status status,
                                                Pageable pageable) throws JsonProcessingException {
        log.info("Inside getByRoleView method of SuspensionCollateralController");
        return ResponseEntity.ok(CommonUtil.encodedJsonResponse(service.findByFilters(officerId, status, pageable), objectMapper));
    }

    private <T> String buildJsonResponse(T response) throws JsonProcessingException {
        return objectMapper.writeValueAsString(ResponseDTO.<T>builder().status(200).result(response).build());
    }
}
