package app.ewarehouse.repository;

import app.ewarehouse.entity.Seasonality;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SeasonalityRepository extends JpaRepository<Seasonality, Integer>{

}
