package app.ewarehouse.repository;

import app.ewarehouse.entity.TreceiveCommodity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TreceiveCommodityRepository extends JpaRepository<TreceiveCommodity ,String> {
    @Query("FROM TreceiveCommodity t where t.bitDeleteFlag = :bitDeleteFlag ORDER BY dtmCreatedAt DESC")
    Page<TreceiveCommodity> findAllByBitDeleteFlag(Pageable pageable, boolean bitDeleteFlag);

    TreceiveCommodity findByTxtReceiveCIdAndBitDeleteFlag(String txtReceiveCId, boolean bitDeleteFlag);

    @Query("FROM TreceiveCommodity t ORDER BY dtmCreatedAt DESC")
    List<TreceiveCommodity> findAllByBitDeleteFlag(boolean bitDeleteFlag);

    TreceiveCommodity findByDepositor_IntId(String id);
}
