package app.ewarehouse.dto;

import java.util.List;

import app.ewarehouse.entity.Action;
import app.ewarehouse.entity.OperatorLicenceFiles;
import app.ewarehouse.entity.OperatorLicenceRemarks;
import app.ewarehouse.entity.Stakeholder;
import app.ewarehouse.entity.Status;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OperatorLicenceDTO {
    private Integer id;
    private String businessName;
    private String businessRegNumber;
    private String businessEntityType;
    private String businessAddress;
    private String emailAddress;
    private String phoneNumber;
    private String kraPin;
    private String physicalAddressWarehouse;
    private Integer warehouseSize;
    private String goodsStored;
    private Integer storageCapacity;
    private String securityMeasures;
    private String wasteDisposalMethods;
    private Boolean declaration;
    private String paymentMethod;
    private Status status;
    private Action action;
    private Stakeholder forwardedTo;
    private List<OperatorLicenceRemarks> remarks;
    private List<OperatorLicenceFiles> files;
}

