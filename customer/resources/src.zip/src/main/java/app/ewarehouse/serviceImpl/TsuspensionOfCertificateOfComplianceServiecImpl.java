package app.ewarehouse.serviceImpl;

import java.util.*;
import app.ewarehouse.dto.TakeActionRequest;
import app.ewarehouse.entity.*;
import app.ewarehouse.exception.CustomGeneralException;
import app.ewarehouse.util.*;
import com.fasterxml.jackson.core.type.TypeReference;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import app.ewarehouse.repository.TsuspensionOfCertificateOfComplianceRepository;
import app.ewarehouse.service.TsuspensionOfCertificateOfComplianceService;

@Service
public class TsuspensionOfCertificateOfComplianceServiecImpl implements TsuspensionOfCertificateOfComplianceService {

	@Autowired
	TsuspensionOfCertificateOfComplianceRepository suspensionRepository;
	@Autowired
	ErrorMessages errorMessages;
	@Autowired
	private UserIdConstants userIdConstants;
	@Autowired
	private Validator validator;
	private static final Logger logger = LoggerFactory.getLogger(TsuspensionOfCertificateOfComplianceServiecImpl.class);

	@Override
	public TsuspensionOfCertificateOfCompliance createSuspension(String complaintFormDto) throws JsonMappingException, JsonProcessingException {
		try {
		logger.info("inside in service Impl");
		String decodedData = CommonUtil.inputStreamDecoder(complaintFormDto);
		   TsuspensionOfCertificateOfCompliance suspensionCompliance  = new ObjectMapper().readValue(decodedData, TsuspensionOfCertificateOfCompliance.class);
			suspensionCompliance.setStatus(Status.Pending);
			suspensionCompliance.setSupportingDocument(JsonFileExtractorUtil.uploadFile(suspensionCompliance.getSupportingDocument(), FolderAndDirectoryConstant.SUSPENSION_COMPLIANCE));

			suspensionCompliance.setIntOfficerStage(userIdConstants.getCeo());

			Set<ConstraintViolation<TsuspensionOfCertificateOfCompliance>> violations = validator.validate(suspensionCompliance);
			if (!violations.isEmpty()) {
				throw new CustomGeneralException(violations);
			}
			suspensionRepository.save(suspensionCompliance);
		return suspensionCompliance;
		} catch (DataIntegrityViolationException exception) {
			throw new CustomGeneralException(errorMessages.getContactNotUnique());
		} catch (CustomGeneralException exception){
			throw exception;
		}catch (JsonProcessingException e) {
			throw new CustomGeneralException(errorMessages.getInternalServerError());
		}catch (Exception e){
			throw new CustomGeneralException(errorMessages.getUnknownError());
		}
	}

	@Override
	public TsuspensionOfCertificateOfCompliance getSuspensionByComplaintNumber(String id) {
        return suspensionRepository.findByComplaintNumberAndIsDeleted(id,false);
	}

	@Override
	public boolean isContactNumberUnique(String contactNumber) {
        return suspensionRepository.existsByComplainantContactNumberAndIsDeleted(contactNumber,false);
	}

	@Override
	public Page<TsuspensionOfCertificateOfCompliance> getAllSuspensions(int page, int size) {
		 Pageable pageable = PageRequest.of(page, size);
	        return suspensionRepository.findAllByIsDeleted(pageable,false);
	}
	@Override
	public List<TsuspensionOfCertificateOfCompliance> getAllSuspensions() {
		return suspensionRepository.findByIsDeleted(false);
	}

	@Override
	public Page<TsuspensionOfCertificateOfCompliance> findByFilters(Integer intOfficerStage, Status status, Pageable pageable) {
		logger.info("Inside findByFilters method of SuspensionCollateralServiceImpl");
		Page<TsuspensionOfCertificateOfCompliance> suspensionPage = suspensionRepository.findByFilters(intOfficerStage, getOfficersAbove(intOfficerStage), status, Status.Pending, Status.Forwarded, Status.Approved, Status.Rejected, pageable);
		return new PageImpl<>(suspensionPage.getContent(), pageable, suspensionPage.getTotalElements());
	}

	@Override
	public String takeAction(String data) {
		logger.info("Inside takeAction method of SuspensionCollateralServiceImpl");

		String decodedData = CommonUtil.inputStreamDecoder(data);
		TakeActionRequest<TsuspensionOfCertificateOfCompliance> rcTakeAction;

		try {
			rcTakeAction = new ObjectMapper().readValue(decodedData, new TypeReference<TakeActionRequest<TsuspensionOfCertificateOfCompliance>>() {});
		} catch (Exception e) {
			logger.error("Inside save method of SuspensionCollateralServiceImpl some error occur:" + e.getMessage());
			throw new CustomGeneralException("Invalid JSON data format");
		}

		String suspensionComplaintNumber = rcTakeAction.getData().getComplaintNumber();
		TsuspensionOfCertificateOfCompliance existingSuspensionCollateral = suspensionRepository
				.findByComplaintNumberAndIsDeleted(suspensionComplaintNumber, false);

		Integer currentOfficerId = rcTakeAction.getOfficerRole();
		boolean isSecondCeo = Objects.equals(existingSuspensionCollateral.getIntOfficerStage(), userIdConstants.getCeo());

		validateApprovalDetails(existingSuspensionCollateral, rcTakeAction);

		if (rcTakeAction.getAction().equals(Status.Approved)) {
			existingSuspensionCollateral.setIntOfficerStage(getNextSuspensionOfficer(currentOfficerId));
			existingSuspensionCollateral.setStatus(Status.Pending);
			if (isSecondCeo) {
				existingSuspensionCollateral.setStatus(Status.Approved);
			}
		} else if (rcTakeAction.getAction().equals(Status.Rejected)) {
			existingSuspensionCollateral.setIntOfficerStage(currentOfficerId);
			existingSuspensionCollateral.setStatus(Status.Rejected);
		} else {
			throw new CustomGeneralException("This operation is not allowed.");
		}

		try {
			suspensionRepository.save(existingSuspensionCollateral);
		}
		catch (Exception exception) {
			throw new CustomGeneralException("Sorry an unknown error occurred. Please try again.");
		}
		return existingSuspensionCollateral.getComplaintNumber();
	}

	private void validateApprovalDetails(TsuspensionOfCertificateOfCompliance suspensionCollateral, TakeActionRequest<TsuspensionOfCertificateOfCompliance> rcTakeAction) {
		int roleId = rcTakeAction.getOfficerRole();
		TsuspensionOfCertificateOfCompliance submittedSuspensionCollateral = rcTakeAction.getData();
		Status actionToPerform = rcTakeAction.getAction();
		boolean isOfficerInHierarchyPending = Objects.equals(suspensionCollateral.getIntOfficerStage(), roleId);

		// Map role IDs to their corresponding actions using Runnable instances (lambda expressions)
		Map<Integer, Runnable> approvalActions = Map.of(
				userIdConstants.getCeo(), () -> {

					// Cannot perform action on an approved application, Can only perform actions on what is in his pending hierarchy.
					if (!isOfficerInHierarchyPending || suspensionCollateral.getStatus() == Status.Approved) {
						throw new CustomGeneralException("This operation is not allowed.");
					}

					// Cannot reject an already rejected application
					if (suspensionCollateral.getStatus() == Status.Rejected && actionToPerform == Status.Rejected) {
						throw new CustomGeneralException("You cannot reject a rejected application.");
					}

					suspensionCollateral.setRemark(submittedSuspensionCollateral.getRemark());
				},
				userIdConstants.getOicLegal(), () -> {
					// OIC_LEGAL cannot reject an application
					if (!isOfficerInHierarchyPending ||  actionToPerform == Status.Rejected) {
						throw new CustomGeneralException("Operation not allowed.");
					}

					suspensionCollateral.setVchOicLegalRemark(submittedSuspensionCollateral.getVchOicLegalRemark());
				},
				userIdConstants.getInspector(), () -> {

					// Inspector cannot reject an application
					if (!isOfficerInHierarchyPending ||  actionToPerform == Status.Rejected) {
						throw new CustomGeneralException("Operation not allowed.");
					}

					suspensionCollateral.setVchInspectorRemark(submittedSuspensionCollateral.getVchInspectorRemark());
					suspensionCollateral.setVchInspectionDocument(JsonFileExtractorUtil.uploadFile(submittedSuspensionCollateral.getVchInspectionDocument(), "SC_Inspection_Document_"+suspensionCollateral.getComplaintNumber(), FolderAndDirectoryConstant.SUSPENSION_COLLATERAL_INSPECTION_FOLDER));
				},
				userIdConstants.getApprover(), () -> {
					// Approver cannot reject an application
					if (!isOfficerInHierarchyPending ||  actionToPerform == Status.Rejected) {
						throw new CustomGeneralException("Operation not allowed.");
					}

					suspensionCollateral.setVchApproverRemark(submittedSuspensionCollateral.getVchApproverRemark());
				},
				userIdConstants.getCeo(), () -> {

					// Cannot perform action on an approved application, Can only perform actions on what is in his pending hierarchy.
					if (!isOfficerInHierarchyPending || suspensionCollateral.getStatus() == Status.Approved) {
						throw new CustomGeneralException("This operation is not allowed.");
					}

					// Cannot reject an already rejected application
					if (suspensionCollateral.getStatus() == Status.Rejected && actionToPerform == Status.Rejected) {
						throw new CustomGeneralException("You cannot reject a rejected application.");
					}

					suspensionCollateral.setVchCeoSecondRemark(submittedSuspensionCollateral.getVchCeoSecondRemark());
					suspensionCollateral.setVchSuspensionConclusion(submittedSuspensionCollateral.getVchSuspensionConclusion());
				}
		);

		Runnable action = approvalActions.get(roleId);
		if (action != null) {
			action.run();
		}
	}

	/**
	 * Suspension Collateral Role Based
	 */
	private final Map<Integer, Integer> suspensionCollateralHierarchyMap = new HashMap<>();

	public void setSuspensionCollateralHierarchyMap() {
		suspensionCollateralHierarchyMap.put(userIdConstants.getCeo(), userIdConstants.getOicLegal());
		suspensionCollateralHierarchyMap.put(userIdConstants.getOicLegal(), userIdConstants.getInspector());
		suspensionCollateralHierarchyMap.put(userIdConstants.getInspector(), userIdConstants.getApprover());
		suspensionCollateralHierarchyMap.put(userIdConstants.getApprover(), userIdConstants.getCeo());
		suspensionCollateralHierarchyMap.put(userIdConstants.getCeo(), userIdConstants.getCeo());
	}

	public int getNextSuspensionOfficer(int currentOfficer) {
		if (suspensionCollateralHierarchyMap.containsKey(currentOfficer)) {
			return suspensionCollateralHierarchyMap.get(currentOfficer);
		} else {
			throw new CustomGeneralException("Unauthorised user");
		}
	}

	public List<Integer> getOfficersAbove(int currentOfficer) {
		List<Integer> officersAbove = new ArrayList<>();

		Integer nextOfficer = suspensionCollateralHierarchyMap.get(currentOfficer);
		while (nextOfficer != null && !nextOfficer.equals(currentOfficer)) {
			officersAbove.add(nextOfficer);
			currentOfficer = nextOfficer;
			nextOfficer = suspensionCollateralHierarchyMap.get(currentOfficer);
		}

		return officersAbove;
	}

}
