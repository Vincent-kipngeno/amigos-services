package app.ewarehouse.serviceImpl;

import org.springframework.data.jpa.repository.JpaRepository;

import app.ewarehouse.entity.OperatorLicenceRemarks;

public interface OperatorLicenceRemarkRepository extends JpaRepository<OperatorLicenceRemarks, Integer> {

}
