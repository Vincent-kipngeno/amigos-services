package app.ewarehouse.entity;

public enum draftStatus {
    Draft,
    Payment
}
