package app.ewarehouse.entity;

public enum PaymentStatus {

	SUCCESS , FAILED
}
