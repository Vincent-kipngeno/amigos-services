package app.ewarehouse.controller;

import app.ewarehouse.dto.ResponseDTO;
import app.ewarehouse.service.DisputeDeclarationService;
import app.ewarehouse.util.CommonUtil;
import app.ewarehouse.util.FileDownloadUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping("/dispute-declarations")
@Slf4j
public class DisputeDeclarationController {
    private final DisputeDeclarationService disputeDeclarationService;
    private final ObjectMapper objectMapper;

    public DisputeDeclarationController(DisputeDeclarationService disputeDeclarationService, ObjectMapper objectMapper) {
        this.disputeDeclarationService = disputeDeclarationService;
        this.objectMapper = objectMapper;
    }

    @PostMapping
    public ResponseEntity<String> create(@RequestBody String data) throws JsonProcessingException {
        log.info("Inside create method of DisputeDeclarationController");
        ResponseDTO<Object> responseDTO = ResponseDTO.builder()
                .status(HttpStatus.CREATED.value())
                .message(disputeDeclarationService.create(data))
                .build();
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(objectMapper.writeValueAsString(responseDTO)).toString());
    }


    @GetMapping("/all")
    public ResponseEntity<?> getAll(@RequestParam(value = "pageNumber", required = false) Integer pageNumber, @RequestParam(value = "pageSize", required = false) Integer pageSize) throws JsonProcessingException {
        log.info("Inside getAll method of DisputeDeclarationController");
        ResponseDTO<Object> responseDTO = new ResponseDTO<>();
        responseDTO.setStatus(HttpStatus.OK.value());
        if (pageNumber != null && pageSize != null) {
            responseDTO.setResult(disputeDeclarationService.getAll(pageNumber, pageSize));
        } else {
            responseDTO.setResult(disputeDeclarationService.getAll());
        }
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(objectMapper.writeValueAsString(responseDTO)).toString());
    }

    @GetMapping("/download")
    public ResponseEntity<InputStreamResource> download(@RequestParam("filePath") String filePath, HttpServletRequest request, HttpServletResponse response) throws IOException {
        log.info("Inside download method of  DisputeDeclarationController");
        String[] parts = filePath.split("/");
        String fileName = parts[parts.length - 1];
        return FileDownloadUtil.fileDownloadUtil(fileName, filePath, response, request);
    }

    @GetMapping("/pending")
    public ResponseEntity<String> getPendingDisputes(@RequestParam Integer userId, @RequestParam(value = "pageNumber", required = false) Integer pageNumber, @RequestParam(value = "pageSize", required = false) Integer pageSize) throws JsonProcessingException {
        log.info("Inside getPendingDisputes method of  DisputeDeclarationController");
        ResponseDTO<Object> responseDTO = new ResponseDTO<>();
        responseDTO.setStatus(HttpStatus.OK.value());
        if (pageNumber != null && pageSize != null) {
            responseDTO.setResult(disputeDeclarationService.getPendingDisputesForUser(pageNumber, pageSize, userId));
        } else {
            responseDTO.setResult(disputeDeclarationService.getPendingDisputesForUser(userId));
        }
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(objectMapper.writeValueAsString(responseDTO)).toString());
    }

    @GetMapping("/forwarded")
    public ResponseEntity<String> getForwardedDisputes(@RequestParam Integer userId, @RequestParam(value = "pageNumber", required = false) Integer pageNumber, @RequestParam(value = "pageSize", required = false) Integer pageSize) throws JsonProcessingException {
        log.info("Inside getForwardedDisputes method of  DisputeDeclarationController");
        return buildResponse(disputeDeclarationService.getForwardedDisputes(pageNumber, pageSize, userId));
    }

    @GetMapping
    public ResponseEntity<String> getDeclarationDispute(@RequestParam("disputeDeclarationNumber") String disputeDeclarationNumber) throws JsonProcessingException {
        log.info("Inside getDeclarationDispute method of  DisputeDeclarationController");
        return buildResponse(disputeDeclarationService.getByDisputeDeclarationNumber(disputeDeclarationNumber));
    }

    @GetMapping("/forward")
    public ResponseEntity<String> forwardDispute(@RequestParam(value = "declarationNumber") String declarationNumber, @RequestParam("userId") Integer userId, @RequestParam("remark") String remark) throws JsonProcessingException {
        log.info("Inside forwardDispute method of  DisputeDeclarationController");
        disputeDeclarationService.forwardDispute(declarationNumber, userId, remark);
        return buildResponse(HttpStatus.OK.getReasonPhrase());
    }

    @GetMapping("/reject")
    public ResponseEntity<String> rejectDispute(@RequestParam("declarationNumber") String declarationNumber, @RequestParam("userId") Integer userId, @RequestParam("remark") String remark) throws JsonProcessingException {
        log.info("Inside rejectDispute method of DisputeDeclarationController");
        disputeDeclarationService.rejectDispute(declarationNumber, userId, remark);
        return buildResponse(HttpStatus.OK.getReasonPhrase());
    }

    @GetMapping("/approve")
    public ResponseEntity<String> approveDispute(@RequestParam("declarationNumber") String declarationNumber, @RequestParam("userId") Integer userId, @RequestParam("remark") String remark) throws JsonProcessingException {
        log.info("Inside approveDispute method of DisputeDeclarationController");
        disputeDeclarationService.approveDispute(declarationNumber, userId, remark);
        return buildResponse(HttpStatus.OK.getReasonPhrase());
    }


    private ResponseEntity<String> buildResponse(Object result) throws JsonProcessingException {
        ResponseDTO<Object> responseDTO = new ResponseDTO<>();
        responseDTO.setStatus(HttpStatus.OK.value());
        responseDTO.setResult(result);
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(objectMapper.writeValueAsString(responseDTO)).toString());
    }
}



