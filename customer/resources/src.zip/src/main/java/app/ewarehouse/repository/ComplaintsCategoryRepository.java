package app.ewarehouse.repository;

import app.ewarehouse.entity.ComplaintsCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ComplaintsCategoryRepository extends JpaRepository<ComplaintsCategory, Integer>{

}
