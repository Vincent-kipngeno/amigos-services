package app.ewarehouse.repository;

import app.ewarehouse.entity.Action;
import app.ewarehouse.entity.OperatorLicence;
import app.ewarehouse.entity.Stakeholder;
import app.ewarehouse.entity.Status;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OperatorLicenceRepository extends JpaRepository<OperatorLicence, Integer> {
	Page<OperatorLicence> findByStatusAndForwardedToAndAction(Status status, Stakeholder stakeholder,
			Action action, Pageable pageable);
}
