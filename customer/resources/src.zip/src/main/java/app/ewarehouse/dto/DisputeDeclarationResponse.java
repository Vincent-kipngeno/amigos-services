package app.ewarehouse.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Builder;
import lombok.Data;

import java.util.Date;

@Data
@Builder
public class DisputeDeclarationResponse {
    private String disputeDeclarationNumber;
    private InspectorSuspensionComplaintResponse inspectorSuspensionComplaintResponse;
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MMM-yyyy")
    private Date dateOfOccurrence;
    private String locationOfOccurrence;
    private String disputeCategoryName;
    private String descriptionOfDispute;
    private String disputeSupportingDocumentType;
    private String supportingDocument;
    private String status;
    private String remark;
    private String ceoRemark;
    private String iocLegalRemark;
    private String inspectorRemark;
    private Integer actionTakenBy;
}
