package app.ewarehouse.service;

import org.json.JSONObject;

public interface ManageLanguageService {

	JSONObject getActiveLanguageDetailsList();
}
