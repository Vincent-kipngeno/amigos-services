package app.ewarehouse.serviceImpl;

import app.ewarehouse.dto.ApplicationCollateralDTO;
import app.ewarehouse.dto.TakeActionRequest;
import app.ewarehouse.entity.*;
import app.ewarehouse.exception.CustomGeneralException;
import app.ewarehouse.mapper.ApplicationCollateralMapper;
import app.ewarehouse.repository.TapplicationOfCertificateOfComplianceRepository;
import app.ewarehouse.service.TapplicationOfCertificateOfComplianceService;
import app.ewarehouse.util.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class TapplicationOfCertificateOfComplianceServiceImpl implements TapplicationOfCertificateOfComplianceService {

    @Autowired
    TapplicationOfCertificateOfComplianceRepository repo;
    @Autowired
    ObjectMapper objectMapper;
    @Autowired
    private UserIdConstants userIdConstants;
    @Autowired
    private ErrorMessages errorMessages;

    @Override
    public ApplicationCollateralDTO save(String certApplication) throws JsonProcessingException {
        String decodedData = CommonUtil.inputStreamDecoder(certApplication);

        try {
            TapplicationOfCertificateOfCompliance application=  objectMapper.readValue(decodedData,TapplicationOfCertificateOfCompliance.class);
            application.setTxtDirectorIDs(JsonFileExtractorUtil.uploadFile(application.getTxtDirectorIDs(), FolderAndDirectoryConstant.APPLICATION_CERTIFICATE_COLLATERAL_FOLDER));
            application.setTxtDirectorsPassports(JsonFileExtractorUtil.uploadFile(application.getTxtDirectorsPassports(), FolderAndDirectoryConstant.APPLICATION_CERTIFICATE_COLLATERAL_FOLDER));
            application = repo.save(application);
            return ApplicationCollateralMapper.mapToDTO(application);
        }
        catch (DataIntegrityViolationException exception) {
            log.error("Inside save method of TapplicationOfCertificateOfComplianceServiceImpl some error occur:" + exception.getMessage());
            throw new CustomGeneralException(errorMessages.getConstraintError());
        }
        catch (CustomGeneralException exception) {
            log.error("Inside save method of TapplicationOfCertificateOfComplianceServiceImpl some error occur:" + exception.getMessage());
            throw exception;
        }
        catch (Exception e) {
            log.error("Inside save method of TapplicationOfCertificateOfComplianceServiceImpl some error occur:" + e.getMessage());
            throw new CustomGeneralException(errorMessages.getInternalServerError());
        }
    }

    @Override
    public List<TapplicationOfCertificateOfCompliance> findAll() {
          return repo.findAllByBitDeletedFlag(false);
    }

    @Override
    public ApplicationCollateralDTO getApplication(Integer roleId,String status) {
            return ApplicationCollateralMapper.mapToDTO(repo.findByStatusAndIntCurrentRoleAndBitDeletedFlag(draftStatus.valueOf(status),roleId, false));
    }

    @Override
        public Page<ApplicationCollateralDTO> findByFilters(Integer intCurrentRole, Status status, Pageable pageable) {
        log.info("Inside findByFilters method of TapplicationOfCertificateOfComplianceServiceImpl");

        List<Integer> myStages = getStagesByUserId(intCurrentRole, 0);
        List<Integer> immediateBelowStages = getStagesByUserId(intCurrentRole, -1);
        int minStage = myStages.stream().min(Integer::compareTo).orElseThrow(() -> new CustomGeneralException(errorMessages.getInternalServerError()));

        Page<TapplicationOfCertificateOfCompliance> applicationCompliancePage = repo.findByFilters(intCurrentRole, minStage, immediateBelowStages, myStages, status, Status.Pending, Status.Forwarded,Status.Approved, Status.Rejected,Status.OnHold, pageable);

        List<ApplicationCollateralDTO> applicationComplianceDTOList = applicationCompliancePage.getContent().stream()
                .map(ApplicationCollateralMapper::mapToDTO)
                .collect(Collectors.toList());

        long totalElements = applicationCompliancePage.getTotalElements();

        // Clear unused lists
        applicationCompliancePage.getContent().clear();
        myStages.clear();
        immediateBelowStages.clear();

        return new PageImpl<>(applicationComplianceDTOList, pageable, totalElements);
    }

    @Override
    public String takeAction(String data) {
        log.info("Inside takeAction method of TapplicationOfCertificateOfComplianceServiceImpl");

        String decodedData = CommonUtil.inputStreamDecoder(data);
        TakeActionRequest<TapplicationOfCertificateOfCompliance> acTakeAction;

        try {
            acTakeAction = new ObjectMapper().readValue(decodedData, new TypeReference<>() {});
        } catch (Exception e) {
            log.error("Inside save method of TapplicationOfCertificateOfComplianceServiceImpl some error occur:" + e.getMessage());
            throw new CustomGeneralException(errorMessages.getInternalServerError());
        }

        String applicationComplianceId = acTakeAction.getData().getTxtApplicationId();
        TapplicationOfCertificateOfCompliance existingCertificate = repo
                .findById(applicationComplianceId)
                .orElseThrow(() -> new CustomGeneralException(errorMessages.getEntityNotFound()));

        Integer intCurrentRole = acTakeAction.getOfficerRole();

        int approvalStage = existingCertificate.getIntApprovalStage();

        if (existingCertificate.getEnmApprovalStatus().equals(Status.OnHold) && Objects.equals(existingCertificate.getIntCurrentRole(), intCurrentRole)) {
            approvalStage += 1;
        }

        getApprovalDetails(existingCertificate, acTakeAction, approvalStage);

        if (acTakeAction.getAction().equals(Status.Approved)) {

            existingCertificate.setIntCurrentRole(getNextOfficerRole(new CompositeKey(intCurrentRole, approvalStage)));
            existingCertificate.setIntApprovalStage(approvalStage + 1);
            existingCertificate.setEnmApprovalStatus(Status.Pending);

            if (Objects.equals(intCurrentRole, userIdConstants.getCeo())) {
                existingCertificate.setEnmApprovalStatus(Status.Approved);
            }
        } else if (acTakeAction.getAction().equals(Status.Deferred)) {
            getNextOfficerRole(new CompositeKey(intCurrentRole, existingCertificate.getIntApprovalStage()));

            existingCertificate.setIntCurrentRole(intCurrentRole);
            existingCertificate.setEnmApprovalStatus(Status.OnHold);
            existingCertificate.setIntApprovalStage(existingCertificate.getIntApprovalStage() - 1);
        }
        else if (acTakeAction.getAction().equals(Status.Rejected) && Objects.equals(intCurrentRole, userIdConstants.getCeo())) {
            existingCertificate.setIntCurrentRole(getNextOfficerRole(new CompositeKey(intCurrentRole, approvalStage)));
            existingCertificate.setIntApprovalStage(approvalStage + 1);
            existingCertificate.setEnmApprovalStatus(Status.Rejected);
        }
        else {
            throw new CustomGeneralException(errorMessages.getNotAuthorized());
        }

        repo.save(existingCertificate);
        return applicationComplianceId;
    }

    private void getApprovalDetails(TapplicationOfCertificateOfCompliance applicationCompliance, TakeActionRequest<TapplicationOfCertificateOfCompliance> acTakeAction, int approvalStage) {
        int roleId = acTakeAction.getOfficerRole();
        TapplicationOfCertificateOfCompliance submittedCompliance = acTakeAction.getData();

        Map<Integer, Runnable> approvalActions = Map.of(
                userIdConstants.getOicLegal(), () -> {
                    if (approvalStage == 1) {
                        applicationCompliance.setVchOicLegalRemark(submittedCompliance.getVchOicLegalRemark());
                    }

                    if (approvalStage == 3) {
                        applicationCompliance.setInspector(submittedCompliance.getInspector());
                    }

                    if (approvalStage == 5) {
                        applicationCompliance.setVchOicLegalThreeRemark(submittedCompliance.getVchOicLegalThreeRemark());
                    }
                },
                userIdConstants.getOicFinance(), () -> applicationCompliance.setVchOicFinRemark(submittedCompliance.getVchOicFinRemark()),
                userIdConstants.getInspector(), () -> {

                    if (!Objects.equals(applicationCompliance.getInspector().getIntId(), acTakeAction.getUserId())) {
                        throw new CustomGeneralException(errorMessages.getNotAuthorized());
                    }

                    TApplicationComplianceInspection inspector = submittedCompliance.getInspectionDetails();
                    inspector.setVchReportFilePath(JsonFileExtractorUtil.uploadFile(inspector.getVchReportFilePath(), "AC_Inspector_Report_"+applicationCompliance.getTxtApplicationId(), FolderAndDirectoryConstant.APPLICATION_COMPLIANCE_INSPECTOR_FOLDER));
                    applicationCompliance.setInspectionDetails(inspector);
                },
                userIdConstants.getApprover(), () -> applicationCompliance.setAproverDetails(submittedCompliance.getAproverDetails()),
                userIdConstants.getCeo(), () -> applicationCompliance.setCeoApprovalDetails(submittedCompliance.getCeoApprovalDetails())
        );

        Runnable action = approvalActions.get(roleId);
        if (action != null) {
            action.run();
        }
    }

    /**
     * Application compliance Role Based
     */
    private final Map<CompositeKey, Integer> applicationComplianceHierarchyMap = new HashMap<>();

    @PostConstruct
    private void initializeHierarchyMap() {
        applicationComplianceHierarchyMap.put(new CompositeKey(userIdConstants.getOicLegal(), 1), userIdConstants.getOicFinance());
        applicationComplianceHierarchyMap.put(new CompositeKey(userIdConstants.getOicFinance(), 2), userIdConstants.getOicLegal());
        applicationComplianceHierarchyMap.put(new CompositeKey(userIdConstants.getOicLegal(), 3), userIdConstants.getInspector());
        applicationComplianceHierarchyMap.put(new CompositeKey(userIdConstants.getInspector(), 4), userIdConstants.getOicLegal());
        applicationComplianceHierarchyMap.put(new CompositeKey(userIdConstants.getOicLegal(), 5), userIdConstants.getApprover());
        applicationComplianceHierarchyMap.put(new CompositeKey(userIdConstants.getApprover(), 6), userIdConstants.getCeo());
        applicationComplianceHierarchyMap.put(new CompositeKey(userIdConstants.getCeo(), 7), userIdConstants.getCeo());
    }

    public int getNextOfficerRole(CompositeKey currentOfficer) {
        if (applicationComplianceHierarchyMap.containsKey(currentOfficer)) {
            return applicationComplianceHierarchyMap.get(currentOfficer);
        } else {
            throw new CustomGeneralException(errorMessages.getNotAuthorized());
        }
    }

    public List<Integer> getStagesByUserId(Integer userId, int direction) {
        List<Integer> stages = new ArrayList<>();

        for (CompositeKey key : applicationComplianceHierarchyMap.keySet()) {
            if (key.getUserId().equals(userId)) {
                stages.add(key.getHierarchyLevel());
            }
        }

        return stages;
    }

}
