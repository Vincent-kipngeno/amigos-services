package app.ewarehouse.master.dto;

import lombok.Data;
/**
 * @author chinmaya.jena
 * @since 03-07-2024
 */
@Data
public class ComplaintStatusMasterDto {
	private String vchComplaintStatusName;
}
