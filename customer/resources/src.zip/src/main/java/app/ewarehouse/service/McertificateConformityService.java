package app.ewarehouse.service;

public interface McertificateConformityService {

}
