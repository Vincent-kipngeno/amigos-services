package app.ewarehouse.entity;

public enum FocusArea {
    Safety,
    Operations,
    Documentation,
    Compliance,
    Security
}
