package app.ewarehouse.repository;

import app.ewarehouse.entity.Bank;
import app.ewarehouse.entity.BuyerDepositorType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BuyerDepositorTypeRepository extends JpaRepository<BuyerDepositorType, Integer> {
    BuyerDepositorType findByIntIdAndBitDeletedFlag(Integer intId, boolean bitDeletedFlag);

    List<BuyerDepositorType> findAllByBitDeletedFlag(Boolean bitDeletedFlag);
}

