package app.ewarehouse.serviceImpl;

import app.ewarehouse.dto.Mail;
import app.ewarehouse.dto.RoutineComplianceDTO;
import app.ewarehouse.dto.TakeActionRequest;
import app.ewarehouse.entity.*;
import app.ewarehouse.repository.FocusAreaItemRepository;
import app.ewarehouse.util.*;
import com.fasterxml.jackson.core.type.TypeReference;
import org.springframework.transaction.annotation.Transactional;
import app.ewarehouse.exception.CustomGeneralException;
import app.ewarehouse.repository.RoutineComplianceRepository;
import app.ewarehouse.service.RoutineComplianceService;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RoutineComplianceServiceImpl implements RoutineComplianceService {

    @Autowired
    private RoutineComplianceRepository routineComplianceRepository;
    @Autowired
    private FocusAreaItemRepository focusAreaItemRepository;
    @Autowired
    private UserIdConstants userIdConstants;
    @Autowired
    private ErrorMessages errorMessages;
    @Autowired
    private Validator validator;
    private static final Logger logger = LoggerFactory.getLogger(RoutineComplianceServiceImpl.class);

    @Transactional
    @Override
    public String save(String data, int loggedInUserId) {
        logger.info("Inside save method of RoutineComplianceServiceImpl");

        String decodedData = CommonUtil.inputStreamDecoder(data);
        RoutineCompliance routineCompliance;

        try {
            routineCompliance = new ObjectMapper().readValue(decodedData, RoutineCompliance.class);

            InspectionObjective inspectionObjective = routineCompliance.getInspectionObjective();
            Set<FocusAreaItem> focusAreaItems = inspectionObjective.getFocusAreaItems();
            inspectionObjective.setFocusAreaItems(null);
            routineCompliance.setInspectionObjective(inspectionObjective);
            routineCompliance.setIntOfficerStage(userIdConstants.getCeo());
            routineCompliance.setVchInspectionPlan("Draft");

            Set<ConstraintViolation<RoutineCompliance>> violations = validator.validate(routineCompliance);
            if (!violations.isEmpty()) {
                throw new CustomGeneralException(violations);
            }

            routineCompliance = routineComplianceRepository.save(routineCompliance);

            for (FocusAreaItem focusAreaItem: focusAreaItems){
                focusAreaItem.setInspectionObjective(routineCompliance.getInspectionObjective());
            }
            focusAreaItemRepository.saveAll(focusAreaItems);
        }
        catch (CustomGeneralException exception) {
            logger.error("Inside save method of RoutineComplianceServiceImpl some error occur:" + exception.getMessage());
            throw exception;
        }
        catch (Exception e) {
            logger.error("Inside save method of RoutineComplianceServiceImpl some error occur:" + e.getMessage());
            throw new CustomGeneralException(errorMessages.getUnknownError());
        }

        return routineCompliance.getVchRoutineComplianceId();
    }

    @Override
    public RoutineComplianceDTO getById(String id) {
        logger.info("Inside getById method of RoutineComplianceServiceImpl");
        RoutineCompliance routineCompliance = routineComplianceRepository.findByVchRoutineComplianceIdAndBitDeleteFlag(id, false);

        return RoutineComplianceMapper.mapRoutineComplianceToDto(routineCompliance);
    }

    @Override
    public List<RoutineComplianceDTO> getAll() {
        logger.info("Inside getAll method of RoutineComplianceServiceImpl");
        List<RoutineCompliance> routineComplianceList = routineComplianceRepository.findAllByBitDeleteFlag(false);
        return routineComplianceList.stream()
                .map(RoutineComplianceMapper::mapRoutineComplianceToDto)
                .collect(Collectors.toList());
    }

    @Override
    public Page<RoutineComplianceDTO> getAll(Pageable pageable) {
        logger.info("Inside getAll pageable method of RoutineComplianceServiceImpl");
        Page<RoutineCompliance> routineCompliancePage = routineComplianceRepository.findAllByBitDeleteFlag(false, pageable);

        List<RoutineComplianceDTO> routineComplianceDTOList = routineCompliancePage.getContent().stream()
                .map(RoutineComplianceMapper::mapRoutineComplianceToDto)
                .collect(Collectors.toList());

        return new PageImpl<>(routineComplianceDTOList, pageable, routineCompliancePage.getTotalElements());
    }

    @Override
    public String deleteById(String id) {
        logger.info("Inside deleteById method of RoutineComplianceServiceImpl");
        RoutineCompliance routineCompliance = routineComplianceRepository.findByVchRoutineComplianceIdAndBitDeleteFlag(id, false);
        routineCompliance.setBitDeleteFlag(true);
        routineComplianceRepository.save(routineCompliance);
        return routineCompliance.getVchRoutineComplianceId();
    }

    @Override
    public Page<RoutineComplianceDTO> findByFilters(Integer intOfficerStage, Pageable pageable) {
        logger.info("Inside findByFilters method of RoutineComplianceServiceImpl");
        Page<RoutineCompliance> routineCompliancePage = routineComplianceRepository.findByFilters(intOfficerStage, userIdConstants.getOicCompliance(), getNextRoutineOfficer(intOfficerStage), Status.Approved, Status.OnHold, pageable);
        List<RoutineComplianceDTO> routineComplianceDTOList = routineCompliancePage.getContent().stream()
                .map(RoutineComplianceMapper::mapRoutineComplianceToDto)
                .collect(Collectors.toList());

        return new PageImpl<>(routineComplianceDTOList, pageable, routineCompliancePage.getTotalElements());
    }

    @Override
    public String takeAction(String data) {
        logger.info("Inside takeAction method of RoutineComplianceServiceImpl");

        String decodedData = CommonUtil.inputStreamDecoder(data);
        TakeActionRequest<RoutineCompliance> rcTakeAction;

        try {
            rcTakeAction = new ObjectMapper().readValue(decodedData, new TypeReference<>() {});
        } catch (Exception e) {
            logger.error("Inside save method of RoutineComplianceServiceImpl some error occur:" + e.getMessage());
            throw new CustomGeneralException("Invalid JSON data format");
        }

        String routineComplianceId = rcTakeAction.getData().getVchRoutineComplianceId();
        RoutineCompliance existingRoutineCompliance = routineComplianceRepository
                .findById(routineComplianceId)
                .orElseThrow(() -> new CustomGeneralException("Entity not found"));

        Integer currentOfficerId = rcTakeAction.getOfficerRole();

        boolean isApproveAction = rcTakeAction.getAction().equals(Status.Approved);
        boolean isDeferAction = rcTakeAction.getAction().equals(Status.Deferred);
        boolean isSecondCeo = Objects.equals(existingRoutineCompliance.getIntOfficerStage(), userIdConstants.getCeo());

        // Validate whether the appropriate approval details have been submitted based on the current inspector/officer
        validateApprovalDetails(existingRoutineCompliance, rcTakeAction);

        if (isApproveAction) {
            existingRoutineCompliance.setIntOfficerStage(getNextRoutineOfficer(currentOfficerId));
            existingRoutineCompliance.setEnmStatus(Status.Pending);
            if (isSecondCeo) {
                existingRoutineCompliance.setEnmStatus(Status.Approved);
            }
        } else if (isDeferAction) {
            existingRoutineCompliance.setIntOfficerStage(currentOfficerId);
            existingRoutineCompliance.setEnmStatus(Status.OnHold);
        } else {
            throw new CustomGeneralException("This operation is not allowed.");
        }

        routineComplianceRepository.save(existingRoutineCompliance);
        return routineComplianceId;
    }

    private void validateApprovalDetails(RoutineCompliance routineCompliance, TakeActionRequest<RoutineCompliance> rcTakeAction) {
        int roleId = rcTakeAction.getOfficerRole();
        RoutineCompliance submittedRoutineCompliance = rcTakeAction.getData();
        Status actionToPerform = rcTakeAction.getAction();
        boolean isOfficerInHierarchyPending = Objects.equals(routineCompliance.getIntOfficerStage(), roleId);
        boolean isOfficerInHierarchyOnHold = Objects.equals(routineCompliance.getIntOfficerStage(), getNextRoutineOfficer(roleId));

        // Map role IDs to their corresponding actions using Runnable instances (lambda expressions)
        Map<Integer, Runnable> approvalActions = Map.of(
                userIdConstants.getOicCompliance(), () -> {
                    // Inspector cannot defer or reject an application
                    if (actionToPerform == Status.Deferred || actionToPerform == Status.Rejected) {
                        throw new CustomGeneralException("Defer operation not allowed.");
                    }

                    // Can only approve a pending application in his pending hierarchy or an onHold operation in his onHold hierarchy
                    if (actionToPerform == Status.Approved && !((routineCompliance.getEnmStatus() == Status.Pending && isOfficerInHierarchyPending) || (routineCompliance.getEnmStatus() == Status.OnHold && isOfficerInHierarchyOnHold))) {
                        throw new CustomGeneralException("Approve operation not allowed.");
                    }

                    routineCompliance.setVchComplianceRemark(submittedRoutineCompliance.getVchComplianceRemark());
                },
                userIdConstants.getCeo(), () -> {
                    if (submittedRoutineCompliance.getCeoApproval() == null) {
                        throw new CustomGeneralException("Ceo approval details required.");
                    }

                    // Cannot perform action on an approved application, Cannot reject, Can only perform actions on what is in his pending hierarchy.
                    if (!isOfficerInHierarchyPending || actionToPerform == Status.Rejected || routineCompliance.getEnmStatus() == Status.Approved) {
                        throw new CustomGeneralException("This operation is not allowed.");
                    }

                    // Cannot defer an already deferred application by himself
                    if (routineCompliance.getEnmStatus() == Status.OnHold && actionToPerform == Status.Deferred) {
                        throw new CustomGeneralException("You cannot defer a deferred application.");
                    }

                    if(actionToPerform == Status.Deferred) {
                        sendMail("Ceo Routine Compliance On Hold", "Hello, please check the inspection details again and review where necessary.");
                    }

                    routineCompliance.setCeoApproval(submittedRoutineCompliance.getCeoApproval());
                },
                userIdConstants.getInspector(), () -> {
                    // Inspector cannot defer or reject an application
                    if (actionToPerform == Status.Deferred || actionToPerform == Status.Rejected) {
                        throw new CustomGeneralException("Defer operation not allowed.");
                    }

                    // Inspector can only forward/schedule a pending application in his/her hierarchy
                    if (actionToPerform == Status.Approved && !(routineCompliance.getEnmStatus() == Status.Pending && isOfficerInHierarchyPending)) {
                        throw new CustomGeneralException("Approve operation not allowed.");
                    }

                    routineCompliance.setVchInspectionPlan("Scheduled");
                },
                userIdConstants.getInspector(), () -> {
                    if (submittedRoutineCompliance.getInspectorTwo() == null) {
                        throw new CustomGeneralException("Inspector two approval details required.");
                    }

                    // Cannot defer or reject an application
                    if (actionToPerform == Status.Deferred || actionToPerform == Status.Rejected) {
                        throw new CustomGeneralException("Defer operation not allowed.");
                    }

                    // Can only approve a pending application in his pending hierarchy or an onHold operation in his onHold hierarchy
                    if (actionToPerform == Status.Approved && !((routineCompliance.getEnmStatus() == Status.Pending && isOfficerInHierarchyPending) || (routineCompliance.getEnmStatus() == Status.OnHold && isOfficerInHierarchyOnHold))) {
                        throw new CustomGeneralException("Approve operation not allowed.");
                    }

                    RoutineComplianceInspectorTwo inspectorTwo = submittedRoutineCompliance.getInspectorTwo();
                    inspectorTwo.setVchReportFilePath(JsonFileExtractorUtil.uploadFile(inspectorTwo.getVchReportFilePath(), "RC_InspectorTwo_Report_"+routineCompliance.getVchRoutineComplianceId(), FolderAndDirectoryConstant.ROUTINE_COMPLIANCE_INSPECTOR_TWO_FOLDER));
                    inspectorTwo.setVchPhotographicEvidenceFilePath(JsonFileExtractorUtil.uploadFile(inspectorTwo.getVchPhotographicEvidenceFilePath(), "RC_InspectorTwo_PhotographicEvidence_"+routineCompliance.getVchRoutineComplianceId(), FolderAndDirectoryConstant.ROUTINE_COMPLIANCE_INSPECTOR_TWO_FOLDER));
                    routineCompliance.setInspectorTwo(inspectorTwo);
                },
                userIdConstants.getOicCompliance(), () -> {
                    if (submittedRoutineCompliance.getComplianceTwo() == null) {
                        throw new CustomGeneralException("Compliance two approval details required.");
                    }

                    // Can only take approve and defer action and only on what is on hold or pending on his side or what is on hold on the hierarchy above
                    if (!(isOfficerInHierarchyPending || isOfficerInHierarchyOnHold) || actionToPerform == Status.Rejected || routineCompliance.getEnmStatus() == Status.Approved) {
                        throw new CustomGeneralException("This operation is not allowed.");
                    }

                    // Can only approve his pending application or a deferred application by himself or the CEO second
                    // Can only defer his pending application or a deferred application by the CEO second
                    if ((actionToPerform == Status.Approved || actionToPerform == Status.Deferred) && !((routineCompliance.getEnmStatus() == Status.Pending && isOfficerInHierarchyPending) || routineCompliance.getEnmStatus() == Status.OnHold)) {
                        throw new CustomGeneralException("Operation not allowed.");
                    }

                    // Cannot defer an already deferred application by himself.
                    if (actionToPerform == Status.Deferred && isOfficerInHierarchyPending && routineCompliance.getEnmStatus() == Status.OnHold) {
                        throw new CustomGeneralException("Application already deferred.");
                    }

                    if(actionToPerform == Status.Deferred) {
                        sendMail("OIC Routine Compliance On Hold", "Hello, please check the compliance inspection again and review where necessary.");
                    }

                    routineCompliance.setComplianceTwo(submittedRoutineCompliance.getComplianceTwo());
                },
                userIdConstants.getCeo(), () -> {
                    if (submittedRoutineCompliance.getCeoSecond() == null) {
                        throw new CustomGeneralException("Ceo Second approval details required.");
                    }

                    // Cannot perform action on an approved application, Cannot reject, Can only perform actions on what is in his pending hierarchy.
                    if (!isOfficerInHierarchyPending || actionToPerform == Status.Rejected || routineCompliance.getEnmStatus() == Status.Approved) {
                        throw new CustomGeneralException("This operation is not allowed.");
                    }

                    // Cannot defer an already deferred application by himself
                    if (routineCompliance.getEnmStatus() == Status.OnHold && actionToPerform == Status.Deferred) {
                        throw new CustomGeneralException("You cannot defer a deferred application.");
                    }

                    if(actionToPerform == Status.Approved) {
                        routineCompliance.setVchInspectionPlan("Finalised");
                    }

                    if(actionToPerform == Status.Deferred) {
                        sendMail("CEO Routine Compliance On Hold", "Hello, please check the compliance inspection again. If need be return the inspection to the Inspector.");
                    }
                    routineCompliance.setCeoSecond(submittedRoutineCompliance.getCeoSecond());
                }
        );

        Runnable action = approvalActions.get(roleId);
        if (action != null) {
            action.run();
        }
    }

    /**
     * Routine compliance Role Based
     */
    private final Map<Integer, Integer> routineComplianceHierarchyMap = new HashMap<>();

     public void setRoutineComplianceHierarchyMap() {
        routineComplianceHierarchyMap.put(userIdConstants.getOicCompliance(), userIdConstants.getCeo());
        routineComplianceHierarchyMap.put(userIdConstants.getCeo(), userIdConstants.getInspector());
        routineComplianceHierarchyMap.put(userIdConstants.getInspector(), userIdConstants.getInspector());
        routineComplianceHierarchyMap.put(userIdConstants.getInspector(), userIdConstants.getOicCompliance());
        routineComplianceHierarchyMap.put(userIdConstants.getOicCompliance(), userIdConstants.getCeo());
        routineComplianceHierarchyMap.put(userIdConstants.getCeo(), userIdConstants.getCeo());
    }

    public int getNextRoutineOfficer(int currentOfficer) {
        if (routineComplianceHierarchyMap.containsKey(currentOfficer)) {
            return routineComplianceHierarchyMap.get(currentOfficer);
        } else {
            throw new CustomGeneralException("Unauthorised user");
        }
    }

    public void sendMail(String subject, String message) {

        Mail mail = new Mail();
        mail.setMailSubject(subject);
        mail.setContentType("text/html");
        mail.setMailCc("uiidptestmail@gmail.com"); // CC mail id
        mail.setTemplate(message);
        mail.setMailTo("kipngenovi2001@gmail.com");
       // EmailUtil.sendMail(mail);
    }
}
