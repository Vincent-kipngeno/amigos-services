package app.ewarehouse.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.Date;

@Entity
@Table(name = "m_dispute_declaration")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DisputeDeclaration {
    @Id
    @GeneratedValue(generator = "dispute-declaration-custom-id")
    @GenericGenerator(
            name = "dispute-declaration-custom-id",
            type = app.ewarehouse.util.CustomIdGenerator.class,
            parameters = {
                    @org.hibernate.annotations.Parameter(name = "tableName", value = "m_dispute_declaration"),
                    @org.hibernate.annotations.Parameter(name = "idName", value = "dispute_id")
            })
    @Column(name = "dispute_id")
    private String disputeId;

    //TODO: Needs to be changed to relevant Applicant Entity
    @ManyToOne
    @JoinColumn(name = "applicant_id")
    private InspectorSuspensionComplaint inspectorSuspensionComplaint;

    @Column(name = "date_of_occurrence")
    private Date dateOfOccurrence;

    @Column(name = "location_of_occurrence")
    private String locationOfOccurrence;

    @ManyToOne
    @JoinColumn(name = "dispute_category_id")
    private DisputeCategory disputeCategory;

    @Column(name = "description_of_dispute")
    private String descriptionOfDispute;

    @ManyToOne
    @JoinColumn(name = "supporting_docType_id")
    private DisputeSupportingDocumentType disputeSupportingDocumentType;

    @Column(name = "supporting_document")
    private String supportingDocument;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private Status status;

    @CreationTimestamp
    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "remark")
    private String remark;

    @Column(name = "ceo_remark")
    private String ceoRemark;

    @Column(name = "oic_legal_remark")
    private String oicLegalRemark;

    @Column(name = "inspector_remark")
    private String inspectorRemark;

    @Column(name = "action_taken_by")
    private Integer actionTakenBy;
}
