package app.ewarehouse.service;

import app.ewarehouse.dto.ComplaintsResponse;
import app.ewarehouse.entity.Complaints;

import java.util.List;

public interface ComplaintsService {
	
    Complaints save(Complaints complaints);

    List<ComplaintsResponse> getAll();

    Complaints getById(String id);

    Complaints update(String id, Complaints updatedComplaints);

    boolean deleteById(Integer id);

}
