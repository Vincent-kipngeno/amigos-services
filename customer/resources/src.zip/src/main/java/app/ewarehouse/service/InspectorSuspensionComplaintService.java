package app.ewarehouse.service;

import app.ewarehouse.dto.InspectorSuspensionComplaintResponse;
import app.ewarehouse.entity.InspectorSuspensionComplaint;
import app.ewarehouse.entity.Status;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

public interface InspectorSuspensionComplaintService {
    String save(String complaintData);
    InspectorSuspensionComplaintResponse getById(String id);
    List<InspectorSuspensionComplaintResponse> getAll();
    Map<String, Object> getAll(Integer pageNumber, Integer pageSize);
    Page<InspectorSuspensionComplaint> getComplaintList(String status, Integer actionTakenBy, Pageable pageable);
    void forwardComplaint(String id, Integer actionTakenBy, String remarks, Status status, Integer userId);
}
