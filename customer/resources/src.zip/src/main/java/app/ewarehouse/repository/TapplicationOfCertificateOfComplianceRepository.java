package app.ewarehouse.repository;

import app.ewarehouse.entity.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TapplicationOfCertificateOfComplianceRepository extends JpaRepository<TapplicationOfCertificateOfCompliance,String> {

    TapplicationOfCertificateOfCompliance findByTxtApplicationIdAndBitDeletedFlag(String applicationId,boolean bitDeletedFlag);

    TapplicationOfCertificateOfCompliance findByStatusAndIntCurrentRoleAndBitDeletedFlag(draftStatus status, Integer roleId,boolean bitDeletedFlag);

    List<TapplicationOfCertificateOfCompliance> findAllByBitDeletedFlag(boolean bitDeletedFlag);

    @Query("SELECT a FROM TapplicationOfCertificateOfCompliance a " +
            "WHERE a.bitDeletedFlag = false AND (" +
            "(:status = :pendingStatus AND ( (:status = a.enmApprovalStatus AND :intCurrentRole = a.intCurrentRole) OR ( (a.intApprovalStage IN :immediateBelowStages OR a.intApprovalStage IN :myStages) AND :onHoldStatus = a.enmApprovalStatus) ) ) OR " +
            "(:status = :forwardedStatus AND a.intApprovalStage > :firstStage AND a.intApprovalStage NOT IN :myStages AND NOT (a.intApprovalStage IN :immediateBelowStages AND :onHoldStatus = a.enmApprovalStatus) ) OR " +
            "(:status IN (:approvedStatus, :rejectedStatus) AND :status = a.enmApprovalStatus))")
    Page<TapplicationOfCertificateOfCompliance> findByFilters(
            @Param("intCurrentRole") Integer intCurrentRole,
            @Param("firstStage") Integer firstStage,
            @Param("immediateBelowStages") List<Integer> immediateBelowStages,
            @Param("myStages") List<Integer> myStages,
            @Param("status") Status status,
            @Param("pendingStatus") Status pendingStatus,
            @Param("forwardedStatus") Status forwardedStatus,
            @Param("approvedStatus") Status approvedStatus,
            @Param("rejectedStatus") Status rejectedStatus,
            @Param("onHoldStatus") Status onHoldStatus,
            Pageable pageable);

    @Query("SELECT r.enmStatus FROM RoutineCompliance r WHERE r.vchRoutineComplianceId = :id AND r.bitDeleteFlag = false")
    Status findStatusById(@Param("id") String id);
}
