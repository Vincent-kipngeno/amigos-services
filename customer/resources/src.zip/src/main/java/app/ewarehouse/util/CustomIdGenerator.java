package app.ewarehouse.util;

import org.hibernate.MappingException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.Configurable;
import org.hibernate.id.IdentifierGenerator;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.type.Type;

import java.io.Serializable;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Properties;

public class CustomIdGenerator implements IdentifierGenerator, Configurable {
    private String tableName;
    private String idName;

    @Override
    public void configure(Type type, Properties parameters, ServiceRegistry serviceRegistry) throws MappingException {
        tableName = parameters.getProperty("tableName");
        idName = parameters.getProperty("idName");
    }

    @Override
    public Serializable generate(SharedSessionContractImplementor session, Object object) {
        try (Connection connection = session.getJdbcConnectionAccess().obtainConnection();
             CallableStatement callableStatement = connection.prepareCall("{CALL GenerateCustomID(?, ?, ?)}")) {
            callableStatement.setString(1, tableName);
            callableStatement.setString(2, idName);
            callableStatement.registerOutParameter(3, Types.VARCHAR);
            callableStatement.execute();
            return callableStatement.getString(3);
        } catch (Exception e) {
            throw new RuntimeException("Error generating custom ID", e);
        }
    }
}
