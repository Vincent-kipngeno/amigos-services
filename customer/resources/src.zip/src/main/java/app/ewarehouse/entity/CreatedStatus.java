package app.ewarehouse.entity;

public enum CreatedStatus {
    Created,
    NotCreated
}
