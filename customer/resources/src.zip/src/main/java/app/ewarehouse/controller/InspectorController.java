package app.ewarehouse.controller;

import app.ewarehouse.dto.InspectorDTO;
import app.ewarehouse.dto.ResponseDTO;
import app.ewarehouse.entity.Action;
import app.ewarehouse.entity.Inspector;
import app.ewarehouse.entity.Stakeholder;
import app.ewarehouse.entity.Status;
import app.ewarehouse.service.InspectorService;
import app.ewarehouse.util.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/inspectors")
@CrossOrigin("*")
public class InspectorController {

	@Autowired
	private InspectorService inspectorService;

	@Autowired
	private ObjectMapper objectMapper;

	@GetMapping("/{id}")
	public ResponseEntity<?> getInspectorById(@PathVariable("id") String id) throws JsonProcessingException {
		Inspector inspector = inspectorService.getInspectorById(Integer.parseInt(id));
		if (inspector != null) {
			return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(inspector)).toString());
		} else {
			throw new EntityNotFoundException("Inspector with id " + id + " not found");
		}
	}
	
	@GetMapping("/ceoGetPendingApplications")
	public ResponseEntity<String> getPendingApplicationsForCeo(@RequestParam(defaultValue = "0") int page,
	                                                           @RequestParam(defaultValue = "5") int size) throws JsonProcessingException {
	    Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Order.desc("id")));
	    Page<InspectorDTO> pendingApplications = inspectorService.getPendingApplicationsForCeo(pageable);
	    return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(pendingApplications)).toString());
	}


//	@GetMapping("/ceoGetPendingAndOnhold")
//	public ResponseEntity<String> getPendingApplicationsForCeo(@RequestParam(defaultValue = "0") int page,
//			@RequestParam(defaultValue = "5") int size) throws JsonProcessingException {
//		Pageable pageable = PageRequest.of(page, size,Sort.by(Sort.Order.desc("id")) );
//		Page<InspectorDTO> pendingApplications = inspectorService.getPendingApplicationsForCeo(pageable);
//		return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(pendingApplications)).toString());
//	}

	@GetMapping("/oicGetPendingAndOnHold")
	public ResponseEntity<String> getPendingApplicationsForOicLegal(@RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "5") int size) throws JsonProcessingException {
		Pageable pageable = PageRequest.of(page, size,Sort.by(Sort.Order.desc("id")));
		Page<InspectorDTO> pendingApplications = inspectorService.getPendingApplicationsForOicLegal(pageable);
		System.out.println(pendingApplications);
		return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(pendingApplications)).toString());
	}
	
	@GetMapping("/approverGetPending")
	public ResponseEntity<String> getPendingApplicationsForApprover(@RequestParam(defaultValue = "0") int page,
	        @RequestParam(defaultValue = "5") int size) throws JsonProcessingException {
	    Pageable pageable = PageRequest.of(page, size,Sort.by(Sort.Order.desc("id")));
	    Page<InspectorDTO> pendingApplications = inspectorService.getPendingApplicationsForApprover(pageable);
	    return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(pendingApplications)).toString());
	}
	
//	@GetMapping("/ceoSecondGetPending")
//	public ResponseEntity<String> getPendingApplicationsForCeoSecond(@RequestParam(defaultValue = "0") int page,
//	        @RequestParam(defaultValue = "5") int size) throws JsonProcessingException {
//		System.out.println("Hellooo!!");
//	    Pageable pageable = PageRequest.of(page, size,Sort.by(Sort.Order.desc("id")));
//	    Page<InspectorDTO> pendingApplications = inspectorService.getPendingApplicationsForCeoSecond(pageable);
//	    System.out.println(pendingApplications);
//	    return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(pendingApplications)).toString());
//	}
	
	@GetMapping("/ceoGetApproved")
	public ResponseEntity<String> getApprovedApplicationsForCeo(@RequestParam(defaultValue = "0") int page,
	                                                            @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
	    Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Order.desc("id")));
	    Page<InspectorDTO> approvedApplications = inspectorService.getApplicationsByStatusAndForwardedTo(Status.Approved, Stakeholder.APPLICANT, pageable);
	    return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(approvedApplications)).toString());
	}

	@GetMapping("/ceoGetRejected")
	public ResponseEntity<String> getRejectedApplicationsForCeo(@RequestParam(defaultValue = "0") int page,
	                                                            @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
	    Pageable pageable = PageRequest.of(page, size,Sort.by(Sort.Order.desc("id")));
	    Page<InspectorDTO> rejectedApplications = inspectorService.getApplicationsByStatusAndForwardedTo(Status.Rejected, Stakeholder.APPLICANT, pageable);
	    return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(rejectedApplications)).toString());
	}

	@GetMapping("/oicGetForwarded")
	public ResponseEntity<String> getForwardedApplicationsForOicLegal(@RequestParam(defaultValue = "0") int page,
	                                                                  @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
	    Pageable pageable = PageRequest.of(page, size,Sort.by(Sort.Order.desc("id")));
	    Page<InspectorDTO> forwardedApplications = inspectorService.getApplicationsByStatusAndForwardedTo(Action.Forwarded, Stakeholder.APPROVER, pageable);
	    System.out.println("Helooo!!"+forwardedApplications.getContent());
	    return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(forwardedApplications)).toString());
	}

	@GetMapping("/approverGetForwarded")
	public ResponseEntity<String> getForwardedApplicationsForApprover(@RequestParam(defaultValue = "0") int page,
	                                                                  @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
	    Pageable pageable = PageRequest.of(page, size,Sort.by(Sort.Order.desc("id")));
	    Page<InspectorDTO> forwardedApplications = inspectorService.getApplicationsByStatusAndForwardedTo(Action.Forwarded, Stakeholder.CEO_SECOND, pageable);
	    return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(forwardedApplications)).toString());
	}

	@GetMapping
	public ResponseEntity<String> getAllInspectors() throws JsonProcessingException {
		List<InspectorDTO> inspectors = inspectorService.getAllInspectors();
		return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(inspectors)).toString());
	}

	@GetMapping("/all")
	public ResponseEntity<String> getAllInspectorsPaged(@RequestParam(defaultValue = "0") int page,
			@RequestParam(defaultValue = "5") int size) throws JsonProcessingException {
		Pageable pageable = PageRequest.of(page, size,Sort.by(Sort.Order.desc("id")));
		Page<InspectorDTO> inspectors = inspectorService.getAllInspectors(pageable);
		return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(inspectors)).toString());
	}

	@PostMapping
	public ResponseEntity<String> createInspector(@RequestBody String inspector) throws JsonProcessingException {
		return ResponseEntity.ok(inspectorService.createInspector(inspector));
	}

	@PostMapping("/ceoAction")
	public ResponseEntity<String> handleCeoAction(@RequestBody String ceoActionRequestData)
			throws JsonProcessingException {
		return ResponseEntity.ok(inspectorService.handleCeoAction(ceoActionRequestData));
	}

	@PostMapping("/oicLegalAction")
	public ResponseEntity<String> handleOicLegalAction(@RequestBody String oicLegalActionRequestData)
			throws JsonProcessingException {
		return ResponseEntity.ok(inspectorService.handleOicLegalAction(oicLegalActionRequestData));
	}
	
	@PostMapping("/approverAction")
	public ResponseEntity<String> handleApproverAction(@RequestBody String approverActionRequestData) throws JsonProcessingException {
	    return ResponseEntity.ok(inspectorService.handleApproverAction(approverActionRequestData));
	}
	
	@PostMapping("/ceoSecondAction")
	public ResponseEntity<String> handleCeoSecondAction(@RequestBody String ceoSecondActionRequestData) throws JsonProcessingException {
	    return ResponseEntity.ok(inspectorService.handleCeoSecondAction(ceoSecondActionRequestData));
	}
	
	private <T> String buildJsonResponse(T response) throws JsonProcessingException {
		return objectMapper.writeValueAsString(ResponseDTO.<T>builder().status(200).result(response).build());
	}
}
