package app.ewarehouse.repository;

import app.ewarehouse.entity.Status;
import app.ewarehouse.entity.TsuspensionOfCertificateOfCompliance;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TsuspensionOfCertificateOfComplianceRepository extends JpaRepository<TsuspensionOfCertificateOfCompliance, String> {

	@Query("from TsuspensionOfCertificateOfCompliance t ORDER BY t.createdAt DESC ")
	Page<TsuspensionOfCertificateOfCompliance> findAllByIsDeleted(Pageable pageable,boolean isDeleted);

	TsuspensionOfCertificateOfCompliance findByComplaintNumberAndIsDeleted(String complaintNumber,boolean isDeleted);

	boolean existsByComplainantContactNumberAndIsDeleted( @Param("contactNumber") String contactNumber,boolean isDeleted);

	@Query("SELECT s FROM TsuspensionOfCertificateOfCompliance s " +
			"WHERE s.isDeleted = false AND (" +
			"(:status = :pendingStatus AND :status = s.status AND :intOfficerStage = s.intOfficerStage) OR " +
			"(:status = :forwardedStatus AND s.intOfficerStage IN :officersAbove) OR " +
			"(:status IN (:approvedStatus, :rejectedStatus) AND :status = s.status))")
	Page<TsuspensionOfCertificateOfCompliance> findByFilters(
			@Param("intOfficerStage") Integer intOfficerStage,
			@Param("officersAbove") List<Integer> officersAbove,
			@Param("status") Status status,
			@Param("pendingStatus") Status pendingStatus,
			@Param("forwardedStatus") Status forwardedStatus,
			@Param("approvedStatus") Status approvedStatus,
			@Param("rejectedStatus") Status rejectedStatus,
			Pageable pageable);

	List<TsuspensionOfCertificateOfCompliance> findByIsDeleted(boolean b);
}
