package app.ewarehouse.dto;

import lombok.Data;

@Data
public class ComplaintTypeRequest {
	
	  private String complaintType;
	  private String complaintStatus;
	  private String selectedComplaintId;
	    

}
