package app.ewarehouse.repository;

import java.util.Date;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import app.ewarehouse.entity.ApplicationOfConformity;
import app.ewarehouse.entity.Status;

@Repository
public interface ApplicationOfConformityRepository extends JpaRepository<ApplicationOfConformity, String> {

	@Query("SELECT a FROM ApplicationOfConformity a WHERE a.bitDeletedFlag = false AND " +
            "(:fromDate IS NULL OR a.dtmCreatedOn >= :fromDate) AND " +
            "(:toDate IS NULL OR a.dtmCreatedOn <= :toDate) AND " +
            "(:status IS NULL OR a.enmStatus = :status)")
    Page<ApplicationOfConformity> findByFilters(@Param("fromDate") Date fromDate,
                                           @Param("toDate") Date toDate,
                                           @Param("status") Status status,
                                           Pageable pageable);

	@Query("SELECT DISTINCT aoc FROM ApplicationOfConformity aoc JOIN FETCH aoc.particularOfApplicantsId poa "
			+ "LEFT JOIN FETCH poa.directors dir " 
			+ "WHERE aoc.applicationId = :applicationId")
	Optional<ApplicationOfConformity> findByApplicationIdWithDirectors(@Param("applicationId") String applicationId);

}
