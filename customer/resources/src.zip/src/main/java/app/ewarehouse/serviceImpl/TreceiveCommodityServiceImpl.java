package app.ewarehouse.serviceImpl;

import app.ewarehouse.dto.BuyerResponse;
import app.ewarehouse.dto.TreceiveCommodityDTO;
import app.ewarehouse.entity.*;
import app.ewarehouse.exception.CustomGeneralException;
import app.ewarehouse.repository.*;
import app.ewarehouse.service.TreceiveCommodityService;
import app.ewarehouse.util.CommonUtil;
import app.ewarehouse.util.ErrorMessages;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.EntityNotFoundException;
import jakarta.validation.Validator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class TreceiveCommodityServiceImpl implements TreceiveCommodityService {

    @Autowired
    TreceiveCommodityRepository repo;
    @Autowired
    private BuyerRepository buyerRepository;

    @Autowired
    private CommodityMasterRepository commodityRepository;

    @Autowired
    private SeasonalityRepository seasonalityRepository;
    @Autowired
    private Validator validator;
    @Autowired
    ErrorMessages errorMessages;



    private static final Logger logger = LoggerFactory.getLogger(TreceiveCommodity.class);

    @Override
    public Page<TreceiveCommodity> getAllCommodities(int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        return Optional.ofNullable(repo.findAllByBitDeleteFlag( pageable,false)).orElse(Page.empty(pageable));
    }

    @Transactional
    @Override
    public String save(String commodities) throws JsonProcessingException {
        try {
            String decodedData = CommonUtil.inputStreamDecoder(commodities);
            TreceiveCommodity treceiveCommodity = new ObjectMapper().readValue(decodedData, TreceiveCommodity.class);
                repo.save(treceiveCommodity);
                return treceiveCommodity.getTxtReceiveCId();
        }catch (DataIntegrityViolationException e){
            logger.error("Data integrity violation: " + e.getMessage());
            throw new CustomGeneralException(errorMessages.getDepositorNonExistent());
        }
        catch (CustomGeneralException exception) {
            throw exception;
        }
        catch (JsonProcessingException e) {
            logger.error("Json Processing violation: "+e);
            throw new CustomGeneralException(errorMessages.getUnknownError());
        }
        catch (Exception e){
            logger.error("General exception:"+e);
            throw new CustomGeneralException(errorMessages.getInternalServerError());
        }

    }

    @Override
    public TreceiveCommodity getCommodityByReceiveId(String txtReceiveCId) {
        TreceiveCommodity commodity = repo.findByTxtReceiveCIdAndBitDeleteFlag(txtReceiveCId,false);
        if (commodity == null) {
            throw new CustomGeneralException(errorMessages.getFailedToFetch() +" "+txtReceiveCId);
        } else if (commodity.getStatus()!=Status.Pending) {
            throw new CustomGeneralException(errorMessages.getAlreadyValidated() + commodity.getStatus());
        }
        return commodity;
    }

    @Override
    public List<TreceiveCommodity> findAll() {
        List<TreceiveCommodity> activeCommodities = repo.findAllByBitDeleteFlag(false);
        return activeCommodities != null ? activeCommodities : Collections.emptyList();
    }

    @Override
    public TreceiveCommodity getCommodityByDepositorsId(String id){
            TreceiveCommodity commodity = repo.findByDepositor_IntId(id);
            if (commodity == null) {
                throw new CustomGeneralException(errorMessages.getNoSuchCommodity());
            }
            return  commodity;
    }
}
