package app.ewarehouse.repository;

import app.ewarehouse.entity.Warehouse_reg;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface Warehouse_regRepository extends JpaRepository<Warehouse_reg, Integer> {
Warehouse_reg findByIntIdAndBitDeletedFlag(Integer intId, boolean bitDeletedFlag);

@Query("From Warehouse_reg where bitDeletedFlag=:bitDeletedFlag ")
List<Warehouse_reg> findAllByBitDeletedFlagAndIntInsertStatus(Boolean bitDeletedFlag,Pageable pageRequest);
Integer countByBitDeletedFlag(Boolean bitDeletedFlag);}