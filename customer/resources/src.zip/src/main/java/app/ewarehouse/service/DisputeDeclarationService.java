package app.ewarehouse.service;

import app.ewarehouse.dto.DisputeDeclarationResponse;
import app.ewarehouse.entity.DisputeDeclaration;

import java.util.List;
import java.util.Map;

public interface DisputeDeclarationService {
    String create (String data);
    List<DisputeDeclarationResponse> getAll();
    Map<String, Object> getAll(Integer pageNumber, Integer pageSize);
    void forwardDispute(String disputeDeclarationNumber, Integer actionTakenBy, String remarks);
    List<DisputeDeclaration> getPendingDisputesForUser(Integer userId);
    Map<String, Object> getPendingDisputesForUser(Integer pageNumber, Integer pageSize, Integer userId);
    Map<String, Object> getForwardedDisputes(Integer pageNumber, Integer pageSize, Integer userId);
    DisputeDeclarationResponse getByDisputeDeclarationNumber(String disputeDeclarationNumber);
    void rejectDispute(String disputeDeclarationNumber, Integer actionTakenBy, String remarks);
    void approveDispute(String disputeDeclarationNumber, Integer userId, String remark);
}
