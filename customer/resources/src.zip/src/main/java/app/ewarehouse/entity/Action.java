package app.ewarehouse.entity;
public enum Action {
    Pending,
    Approved,
    Rejected,
    OnHold,
    InProgress,
    Forwarded
}