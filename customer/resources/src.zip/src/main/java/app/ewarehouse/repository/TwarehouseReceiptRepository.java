package app.ewarehouse.repository;

import app.ewarehouse.entity.TwarehouseReceipt;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface TwarehouseReceiptRepository extends JpaRepository<TwarehouseReceipt,String> {

    @Query("From TwarehouseReceipt t where t.bitDeleteFlag = :bitDeleteFlag ORDER BY t.dtmCreatedAt DESC")
    Page<TwarehouseReceipt> findAllByBitDeleteFlagOrderByDtmCreatedAtDesc(boolean bitDeleteFlag, Pageable pageable);

    TwarehouseReceipt findByTxtWarehouseReceiptIdAndBitDeleteFlag(String txtWarehouseReceiptId, boolean bitDeleteFlag);
}
