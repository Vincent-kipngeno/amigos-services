package app.ewarehouse.controller;

import app.ewarehouse.entity.TvalidateCommodity;
import app.ewarehouse.entity.TwarehouseReceipt;
import app.ewarehouse.service.TwarehouseReceiptService;
import app.ewarehouse.util.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("admin/warehouseReceipt")
@CrossOrigin("*")
public class TwarehouseReceiptController {

    @Autowired
    TwarehouseReceiptService service;
    @Autowired
    ObjectMapper objectMapper;

    @GetMapping
    ResponseEntity<?> getAll() throws JsonProcessingException {
        List<TwarehouseReceipt> response = service.findAll();
        return ResponseEntity.ok(CommonUtil.encodedJsonResponse(response,objectMapper));
    }

    @GetMapping("/paginated")
    ResponseEntity<?> getAllPaginated(
            @RequestParam(value = "page") int page,
            @RequestParam(value = "size") int size) throws JsonProcessingException {
        Page<TwarehouseReceipt> suspensionsPage = service.getAllReceipts(page,size);

        Map<String, Object> response = new HashMap<>();
        response.put("content", suspensionsPage.getContent());
        response.put("totalPages", suspensionsPage.getTotalPages());
        response.put("totalElements", suspensionsPage.getTotalElements());

        return ResponseEntity.ok(CommonUtil.encodedJsonResponse(response,objectMapper));
    }
    @GetMapping("{id}")
    ResponseEntity<?> getDetailsById(@PathVariable String id ) throws Exception {
        TwarehouseReceipt commodity = service.getDetailsById(id);
        return ResponseEntity.ok(CommonUtil.encodedJsonResponse(commodity,objectMapper));
    }
}
