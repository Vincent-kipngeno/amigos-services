package app.ewarehouse.dto;

import lombok.Data;

@Data
public class EntityTypeDto {
	private String vchEntityTypeName;
}
