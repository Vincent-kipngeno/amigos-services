package app.ewarehouse.repository;

import app.ewarehouse.entity.FocusAreaItem;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FocusAreaItemRepository extends JpaRepository<FocusAreaItem, Integer> {
}
