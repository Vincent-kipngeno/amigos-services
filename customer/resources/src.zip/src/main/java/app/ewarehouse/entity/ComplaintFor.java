package app.ewarehouse.entity;

public enum ComplaintFor {
	self,
	others
}
