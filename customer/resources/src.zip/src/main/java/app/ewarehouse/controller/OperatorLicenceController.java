package app.ewarehouse.controller;

import app.ewarehouse.dto.OperatorLicenceDTO;
import app.ewarehouse.dto.ResponseDTO;
import app.ewarehouse.entity.Action;
import app.ewarehouse.entity.Stakeholder;
import app.ewarehouse.entity.Status;
import app.ewarehouse.service.OperatorLicenceService;
import app.ewarehouse.util.CommonUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/admin/operator-licences")
@CrossOrigin("*")
public class OperatorLicenceController {

    private final OperatorLicenceService operatorLicenceService;
    
    @Autowired
    private ObjectMapper objectMapper;

    public OperatorLicenceController(OperatorLicenceService operatorLicenceService) {
        this.operatorLicenceService = operatorLicenceService;
    }
    
    @GetMapping("/technicalGetPending")
    public ResponseEntity<String> getPendingApplicationsForTechnical(@RequestParam(defaultValue = "0") int page,
                                                                     @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
        Pageable pageable = PageRequest.of(page, size);
        Page<OperatorLicenceDTO> pendingApplications = operatorLicenceService.getApplications(pageable, Status.Pending, Stakeholder.TECHNICAL, Action.Pending);
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(pendingApplications)).toString());
    }
    @GetMapping("/revenueGetPending")
    public ResponseEntity<String> getPendingApplicationsForRevenue(@RequestParam(defaultValue = "0") int page,
                                                                   @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
        Pageable pageable = PageRequest.of(page, size);
        Page<OperatorLicenceDTO> pendingApplications = operatorLicenceService.getApplications(pageable, Status.InProgress, Stakeholder.REVENUE, Action.Forwarded);
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(pendingApplications)).toString());
    }

    @GetMapping("/inspectorGetPending")
    public ResponseEntity<String> getPendingApplicationsForInspector(@RequestParam(defaultValue = "0") int page,
                                                                     @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
        Pageable pageable = PageRequest.of(page, size);
        Page<OperatorLicenceDTO> pendingApplications = operatorLicenceService.getApplications(pageable, Status.InProgress, Stakeholder.INSPECTOR, Action.Forwarded);
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(pendingApplications)).toString());
    }

    @GetMapping("/clcGetPending")
    public ResponseEntity<String> getPendingApplicationsForClc(@RequestParam(defaultValue = "0") int page,
                                                               @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
        Pageable pageable = PageRequest.of(page, size);
        Page<OperatorLicenceDTO> pendingApplications = operatorLicenceService.getApplications(pageable, Status.InProgress, Stakeholder.CLC, Action.Forwarded);
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(pendingApplications)).toString());
    }

    @GetMapping("/cecmGetPending")
    public ResponseEntity<String> getPendingApplicationsForCecm(@RequestParam(defaultValue = "0") int page,
                                                                @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
        Pageable pageable = PageRequest.of(page, size);
        Page<OperatorLicenceDTO> pendingApplications = operatorLicenceService.getApplications(pageable, Status.InProgress, Stakeholder.CECM, Action.Forwarded);
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(pendingApplications)).toString());
    }
    
    @GetMapping("/getApprovedApplications")
    public ResponseEntity<String> getApprovedApplications(@RequestParam(defaultValue = "0") int page,
                                                          @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
        Pageable pageable = PageRequest.of(page, size);
        Page<OperatorLicenceDTO> approvedApplications = operatorLicenceService.getApplications(pageable, Status.Approved, Stakeholder.APPLICANT, Action.Forwarded);
        System.out.println(approvedApplications.getContent());
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(approvedApplications)).toString());
    }

    @GetMapping("/getRejectedApplications")
    public ResponseEntity<String> getRejectedApplications(@RequestParam(defaultValue = "0") int page,
                                                          @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
        Pageable pageable = PageRequest.of(page, size);
        Page<OperatorLicenceDTO> rejectedApplications = operatorLicenceService.getApplications(pageable, Status.Rejected, Stakeholder.APPLICANT, Action.Rejected);
        System.out.println(rejectedApplications.getContent());
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(rejectedApplications)).toString());
    }
    
    @GetMapping("/clcGetForwarded")
    public ResponseEntity<String> getForwardedApplicationsToCLC(@RequestParam(defaultValue = "0") int page,
                                                                @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
        Pageable pageable = PageRequest.of(page, size);
        Page<OperatorLicenceDTO> forwardedApplications = operatorLicenceService.getApplications(pageable, Status.Forwarded, Stakeholder.CLC, Action.Forwarded);
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(forwardedApplications)).toString());
    }

    @GetMapping("/cecmGetForwarded")
    public ResponseEntity<String> getForwardedApplicationsToCECM(@RequestParam(defaultValue = "0") int page,
                                                                 @RequestParam(defaultValue = "10") int size) throws JsonProcessingException {
        Pageable pageable = PageRequest.of(page, size);
        Page<OperatorLicenceDTO> forwardedApplications = operatorLicenceService.getApplications(pageable, Status.Forwarded, Stakeholder.CECM, Action.Forwarded);
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(forwardedApplications)).toString());
    }
    
    @PostMapping
    public ResponseEntity<String> createOperatorLicence(@RequestBody String operatorLicence) throws JsonProcessingException {
    	System.out.println(operatorLicence);
        String savedOperatorLicence = operatorLicenceService.saveOperatorLicence(operatorLicence);
        return ResponseEntity.ok(savedOperatorLicence);    
    }
    @PostMapping("/technicalTakeAction")
    public ResponseEntity<String> handleTechnicalAction(@RequestBody String technicalActionRequestData)
            throws JsonProcessingException {
    	System.out.println("Working!!");
        return ResponseEntity.ok(operatorLicenceService.handleAction(technicalActionRequestData, Stakeholder.REVENUE, Stakeholder.TECHNICAL , Action.Forwarded, Status.InProgress));
    }
    @PostMapping("/revenueTakeAction")
    public ResponseEntity<String> handleRevenueAction(@RequestBody String revenueActionRequestData)
            throws JsonProcessingException {
        return ResponseEntity.ok(operatorLicenceService.handleAction(revenueActionRequestData, Stakeholder.INSPECTOR, Stakeholder.REVENUE, Action.Forwarded, Status.InProgress));
    }

    @PostMapping("/inspectorTakeAction")
    public ResponseEntity<String> handleInspectorAction(@RequestBody String inspectorActionRequestData)
            throws JsonProcessingException {
        return ResponseEntity.ok(operatorLicenceService.handleAction(inspectorActionRequestData, Stakeholder.CLC, Stakeholder.INSPECTOR, Action.Forwarded, Status.InProgress));
    }

    @PostMapping("/clcTakeAction")
    public ResponseEntity<String> handleClcAction(@RequestBody String clcActionRequestData)
            throws JsonProcessingException {
        return ResponseEntity.ok(operatorLicenceService.handleAction(clcActionRequestData, Stakeholder.CECM, Stakeholder.CLC, Action.Forwarded, Status.InProgress));
    }

    @PostMapping("/cecmTakeAction")
    public ResponseEntity<String> handleCecmAction(@RequestBody String cecmActionRequestData)
            throws JsonProcessingException {
        return ResponseEntity.ok(operatorLicenceService.handleAction(cecmActionRequestData, Stakeholder.APPLICANT, Stakeholder.CECM, Action.Forwarded, Status.Approved));
    }


    @GetMapping
    public ResponseEntity<String> getOperatorLicences(@RequestParam int page, @RequestParam int size) throws JsonProcessingException {
        return ResponseEntity.ok(CommonUtil.inputStreamEncoder(buildJsonResponse(operatorLicenceService.getOperatorLicences(PageRequest.of(page, size)))).toString());
    }
	
	private <T> String buildJsonResponse(T response) throws JsonProcessingException {
		return objectMapper.writeValueAsString(ResponseDTO.<T>builder().status(200).result(response).build());
	}
}
