package app.ewarehouse.service;

import app.ewarehouse.entity.TwarehouseReceipt;
import org.springframework.data.domain.Page;

import java.util.List;

public interface TwarehouseReceiptService {

    Page<TwarehouseReceipt> getAllReceipts(int page, int size);

    List<TwarehouseReceipt> findAll();

    TwarehouseReceipt getDetailsById(String id);
}
