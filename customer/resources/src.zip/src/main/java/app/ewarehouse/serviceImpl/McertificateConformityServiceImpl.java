package app.ewarehouse.serviceImpl;

import org.springframework.stereotype.Service;

import app.ewarehouse.service.McertificateConformityService;

@Service
public class McertificateConformityServiceImpl implements McertificateConformityService {

}
