package app.ewarehouse.service;

import app.ewarehouse.dto.CountryResponse;

import java.util.List;
import java.util.Map;


public interface CountryService {
    void saveOrUpdate(String data);
    Map<String, Object> getAll(Integer pageNumber, Integer pageSize);
    List<CountryResponse> getAll();
    CountryResponse getById(Integer countryId);
    void toggleActivationStatus(String data);
}
