package app.ewarehouse.repository;

import app.ewarehouse.entity.LegalStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LegalStatusRepository extends JpaRepository<LegalStatus, Integer> {
    LegalStatus findByIntIdAndBitDeletedFlag(Integer intId, boolean bitDeletedFlag);

    List<LegalStatus> findAllByBitDeletedFlag(Boolean bitDeletedFlag);
}
