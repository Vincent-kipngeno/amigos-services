package app.ewarehouse.repository;

import app.ewarehouse.entity.County;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CountyRepository extends JpaRepository<County, Integer> {
	List<County> findByCountryCountryId(Integer countryId);
	Page<County> findAll(Pageable pageable);
}
