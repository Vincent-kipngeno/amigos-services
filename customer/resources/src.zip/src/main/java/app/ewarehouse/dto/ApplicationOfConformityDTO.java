package app.ewarehouse.dto;

import app.ewarehouse.entity.Status;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ApplicationOfConformityDTO {
	private String applicationId;
	private ApplicationOfConformityParticularOfApplicantsDTO particularsDTO;
	private ApplicationOfConformitySupportingDocumentsDTO supportingDocumentsDTO;
	private ApplicationOfConformityWarehouseOperatorViabilityDTO warehouseOperatorDTO;
	private ApplicationOfConformityPaymentDetailsDTO paymentDetailsDTO;
    private Status enmStatus;
    private Integer intCreatedBy;
    private Integer intUpdatedBy;
    private Date dtmCreatedOn;
    private Date stmUpdatedOn;
    private Boolean bitDeletedFlag;
}
