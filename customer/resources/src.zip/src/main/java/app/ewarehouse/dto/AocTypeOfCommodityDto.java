package app.ewarehouse.dto;

import lombok.Data;

@Data
public class AocTypeOfCommodityDto {
	private Integer id;
	private String name;
}
