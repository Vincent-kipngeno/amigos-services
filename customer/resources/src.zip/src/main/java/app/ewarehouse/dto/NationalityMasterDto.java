package app.ewarehouse.dto;

import lombok.Data;

@Data
public class NationalityMasterDto {
	private String vchNationalityName;
}
