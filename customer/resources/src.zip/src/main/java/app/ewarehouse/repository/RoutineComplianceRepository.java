package app.ewarehouse.repository;
import app.ewarehouse.entity.RoutineCompliance;
import app.ewarehouse.entity.Status;
import app.ewarehouse.entity.Tuser;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface RoutineComplianceRepository extends JpaRepository<RoutineCompliance, String> {

    RoutineCompliance findByVchRoutineComplianceIdAndBitDeleteFlag(String intId, boolean bitDeletedFlag);

    List<RoutineCompliance> findAllByBitDeleteFlag(Boolean bitDeletedFlag);

    Page<RoutineCompliance> findAllByBitDeleteFlag(Boolean bitDeletedFlag, Pageable pageable);

    @Query("SELECT r FROM RoutineCompliance r " +
            "WHERE r.bitDeleteFlag = false " +
            "AND (:intOfficerStage = :complianceStage OR " +
            "r.enmStatus = :approvedStatus OR " +
            "(r.enmStatus = :onHoldStatus AND :nextOfficerStage = r.intOfficerStage) OR" +
            ":intOfficerStage = r.intOfficerStage)")
    Page<RoutineCompliance> findByFilters(@Param("intOfficerStage") Integer intOfficerStage,
                                          @Param("complianceStage") Integer complianceStage,
                                          @Param("nextOfficerStage") Integer nextOfficerStage,
                                          @Param("approvedStatus") Status approvedStatus,
                                          @Param("onHoldStatus") Status onHoldStatus,
                                          Pageable pageable);

    @Query("SELECT r.enmStatus FROM RoutineCompliance r WHERE r.vchRoutineComplianceId = :id AND r.bitDeleteFlag = false")
    Status findStatusById(@Param("id") String id);

    @Query("SELECT u FROM Tuser as u WHERE u.selRole=:intRoleId and u.bitDeletedFlag = false")
    List<Tuser> getAllInspectors(@Param("intRoleId")Integer intRoleId);
}
