package app.ewarehouse.entity;
public enum Stakeholder {
    APPLICANT,
    CEO,
    OIC_LEGAL,
    APPROVER,
    CEO_SECOND,
    TECHNICAL,
    REVENUE,
    INSPECTOR,
    CLC,
    CECM  
}

