package app.ewarehouse.util;

import java.util.concurrent.atomic.AtomicInteger;

public class JavaTest {

	public static void main(String[] args) {
		
		AtomicInteger seq = new AtomicInteger(10000);
		int nextVal = seq.incrementAndGet();
         System.out.println(nextVal);
	}

}
