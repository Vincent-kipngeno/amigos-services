//package app.ewarehouse;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class EwarehouseApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
